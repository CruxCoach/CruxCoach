import shlex

from .adapters.blossom import BlossomHttpStore, LocalBlobStore, ReplicatedBlossomStore
from .adapters.nostr import (
    CommandEventSigner,
    EnvironmentNostrSigner,
    EphemeralNostrSigner,
    FileNostrSigner,
    MemoryEventNetwork,
    ReplicatedEventNetwork,
    WebSocketEventNetwork,
)
from .apk import AndroidSdkApkInspector, AndroidSdkApkSigner
from .config import Settings
from .ports import BlobStore, EventNetwork, EventSigner
from .sandbox_inspector import CommandApkInspector
from .service import APKTrackService
from .storage import Registry


def build_service(settings: Settings) -> APKTrackService:
    registry = Registry(settings.database)
    signer: EventSigner
    receipt_signer: EventSigner
    blob_store: BlobStore
    event_network: EventNetwork
    receipt_network: EventNetwork
    if settings.backend == "local":
        signer = EphemeralNostrSigner()
        receipt_signer = EphemeralNostrSigner()
        blob_store = LocalBlobStore(settings.local_blob_directory)
        event_network = MemoryEventNetwork()
        receipt_network = event_network
    else:
        signer = (
            CommandEventSigner(shlex.split(settings.event_signer_command))
            if settings.event_signer_command
            else EnvironmentNostrSigner(settings.operational_secret_env)
        )
        if settings.receipt_signer_command:
            receipt_signer = CommandEventSigner(shlex.split(settings.receipt_signer_command))
        elif settings.receipt_secret_file:
            receipt_signer = FileNostrSigner(settings.receipt_secret_file)
        else:
            receipt_signer = EnvironmentNostrSigner(settings.receipt_secret_env)
        blossom_urls = tuple(
            dict.fromkeys(
                url.strip().rstrip("/")
                for url in (settings.blossom_urls or settings.blossom_url).split(",")
                if url.strip()
            )
        )
        blossom_signer = EphemeralNostrSigner()
        blossom_stores = tuple(BlossomHttpStore(url, blossom_signer) for url in blossom_urls)
        blob_store = ReplicatedBlossomStore(blossom_stores) if len(blossom_stores) > 1 else blossom_stores[0]
        event_network = WebSocketEventNetwork(settings.event_server_url)
        receipt_urls = tuple(
            url.strip() for url in (settings.receipt_event_server_urls or "").split(",") if url.strip()
        ) or (settings.receipt_event_server_url or settings.event_server_url,)
        receipt_networks = tuple(WebSocketEventNetwork(url) for url in receipt_urls)
        receipt_network = (
            ReplicatedEventNetwork(receipt_networks) if len(receipt_networks) > 1 else receipt_networks[0]
        )
    return APKTrackService(
        registry=registry,
        staging_directory=settings.staging_directory,
        blob_store=blob_store,
        event_network=event_network,
        receipt_network=receipt_network,
        signer=signer,
        receipt_signer=receipt_signer,
        inspector=(
            CommandApkInspector(shlex.split(settings.apk_inspector_command))
            if settings.apk_inspector_command
            else AndroidSdkApkInspector()
        ),
        blossom_servers=list(blossom_urls) if settings.backend == "network" else [settings.blossom_url],
        max_apk_bytes=settings.max_apk_bytes,
        ci_policy_file=settings.ci_policy_file,
        apk_signer=(
            AndroidSdkApkSigner(shlex.split(settings.apk_signer_command))
            if settings.apk_signer_command
            else None
        ),
    )
