# ruff: noqa: S108
"""Run Android parsers in a fresh filesystem/network namespace without secrets."""

import json
import subprocess
from pathlib import Path

from .apk import AndroidSdkApkInspector
from .errors import AdapterError
from .models import ApkIdentity


# /tmp below is a fresh private tmpfs inside the namespace.
class SandboxedAndroidInspector(AndroidSdkApkInspector):
    def __init__(self, build_tools: Path, bwrap: str = "/opt/apktrack-sandbox/bwrap") -> None:
        self.build_tools = build_tools.resolve()
        self.bwrap = bwrap
        super().__init__("/tools/apksigner", "/tools/aapt")

    def command(self, tool: list[str]) -> list[str]:
        apk = Path(tool[-1]).resolve(strict=True)
        command = [
            self.bwrap,
            "--unshare-all",
            "--die-with-parent",
            "--new-session",
            "--clearenv",
            "--setenv",
            "JAVA_HOME",
            str(Path("/usr/bin/java").resolve().parent.parent),
            "--setenv",
            "PATH",
            str(Path("/usr/bin/java").resolve().parent) + ":/usr/bin:/bin",
            "--setenv",
            "HOME",
            "/tmp",
            "--ro-bind",
            "/usr",
            "/usr",
            "--proc",
            "/proc",
            "--dev",
            "/dev",
            "--tmpfs",
            "/tmp",
            "--ro-bind",
            str(self.build_tools),
            "/tools",
            "--ro-bind",
            str(apk),
            "/input.apk",
        ]
        for path in ("/bin", "/lib", "/lib64", "/etc/ld.so.cache", "/etc/java-17-openjdk"):
            if Path(path).exists():
                command.extend(["--ro-bind", path, path])
        return [*command, "--", *tool[:-1], "/input.apk"]

    def _run(self, command: list[str]) -> str:
        try:
            result = subprocess.run(
                self.command(command),
                check=False,
                capture_output=True,
                text=True,
                timeout=120,
                env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"},
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise AdapterError("isolated APK inspector unavailable") from exc
        if result.returncode:
            # Do not reflect arbitrary APK/parser output into privileged job logs.
            raise AdapterError("isolated APK verification failed")
        return result.stdout


class CommandApkInspector:
    def __init__(self, command: list[str]) -> None:
        self.command = command

    def inspect(self, apk: Path) -> ApkIdentity:
        try:
            response = subprocess.run(
                [*self.command, str(apk)],
                check=True,
                capture_output=True,
                text=True,
                timeout=300,
                env={"PATH": "/usr/bin:/bin"},
            )
            return ApkIdentity.model_validate_json(response.stdout)
        except (OSError, subprocess.SubprocessError, ValueError) as exc:
            raise AdapterError("isolated APK inspection failed") from exc


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--build-tools", type=Path, required=True)
    parser.add_argument("apk", type=Path)
    args = parser.parse_args()
    identity = SandboxedAndroidInspector(args.build_tools).inspect(args.apk)
    print(json.dumps(identity.model_dump(mode="json")))
