"""GitHub-bound development admission. No signing keys or generic signing RPCs."""

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any

import httpx
import jwt
from coincurve import PublicKeyXOnly
from pydantic import Field

from .errors import ValidationError
from .models import BuildRequest, StrictModel
from .nostr import decode_npub, encode_npub

ISSUER = "https://token.actions.githubusercontent.com"
AUDIENCE = "apktrack:development-publication"


class CIRequest(StrictModel):
    build: BuildRequest
    source_run_id: int = Field(gt=0)
    apk_sha256: str | None = Field(default=None, pattern=r"^[0-9a-f]{64}$")


def read_policy(path: Path) -> dict[str, Any]:
    policy = json.loads(path.read_text())
    if policy.get("schema") != 1:
        raise ValidationError("unsupported CI admission policy")
    return dict(policy)


def account(policy: dict[str, Any], actor: dict[str, Any], track: str) -> str | None:
    """Return the owner's verified npub binding, never a caller-supplied identity."""
    entries = [policy["operator"], *policy["developers"]]
    seen_ids, seen_logins, seen_keys = set(), set(), set()
    found = None
    authorized = False
    for index, entry in enumerate(entries):
        ident, login = entry["github_id"], entry["github_login"]
        if type(ident) is not int or ident <= 0 or not re.fullmatch(r"[A-Za-z0-9-]{1,39}", login):
            raise ValidationError("invalid CI account policy")
        npub = entry.get("npub")
        if npub is not None:
            key = decode_npub(npub)
            if encode_npub(key) != npub:
                raise ValidationError("noncanonical developer npub")
            PublicKeyXOnly(bytes.fromhex(key))
            if key in seen_keys:
                raise ValidationError("duplicate developer npub")
            seen_keys.add(key)
        elif index != 0:
            raise ValidationError("developer must have a verified npub binding")
        if ident in seen_ids or login.casefold() in seen_logins:
            raise ValidationError("duplicate CI account")
        seen_ids.add(ident)
        seen_logins.add(login.casefold())
        enabled = entry.get("enabled", index == 0)
        if type(enabled) is not bool:
            raise ValidationError("invalid enabled flag")
        if actor.get("id") == ident and str(actor.get("login", "")).casefold() == login.casefold():
            scopes = entry.get("tracks", [])
            authorized = enabled and any(
                track == scope or (scope.endswith("*") and track.startswith(scope[:-1])) for scope in scopes
            )
            found = npub
    if not authorized:
        raise ValidationError("GitHub actor is not enabled for this development track")
    return found


def feature_identity(policy: dict[str, Any], branch: str) -> tuple[str, str]:
    if not branch.startswith("feat/") or branch.endswith("/") or ".." in branch:
        raise ValidationError("unsafe feature branch")
    override = policy.get("overrides", {}).get(branch)
    if override is not None:
        return str(override["track"]), str(override["package"])
    digest = hashlib.sha256(branch.encode()).hexdigest()
    slug = re.sub(r"[^a-z0-9]+", "-", branch[5:].lower()).strip("-") or "branch"
    return f"feat-{slug[:43].rstrip('-')}-{digest[:8]}", f"{policy['package_prefix']}.f_{digest[:12]}"


class GitHubAuthority:
    def __init__(self, policy_path: Path, client: httpx.Client | None = None) -> None:
        self.policy_path = policy_path
        self.client = client or httpx.Client(timeout=15, follow_redirects=False)
        self.keys = jwt.PyJWKClient(f"{ISSUER}/.well-known/jwks", timeout=10, lifespan=300)

    def claims(self, token: str) -> dict[str, Any]:
        try:
            if len(token) > 16384:
                raise ValueError("oversized identity token")
            key = self.keys.get_signing_key_from_jwt(token)
            return dict(
                jwt.decode(
                    token,
                    key.key,
                    algorithms=["RS256"],
                    audience=AUDIENCE,
                    issuer=ISSUER,
                    options={"require": ["exp", "iat", "nbf", "jti", "sub"], "strict_aud": True},
                )
            )
        except (jwt.PyJWTError, ValueError) as exc:
            raise ValidationError("GitHub identity token rejected") from exc

    def get(self, path: str) -> dict[str, Any]:
        # Origin is constant. No URLs/redirects or authorization headers from build input.
        headers = {"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}
        token = os.environ.get("APKTRACK_GITHUB_READ_TOKEN")
        if token:
            headers["Authorization"] = f"Bearer {token}"
        try:
            response = self.client.get(f"https://api.github.com/{path}", headers=headers)
            response.raise_for_status()
            return dict(response.json())
        except (httpx.HTTPError, ValueError) as exc:
            raise ValidationError("GitHub evidence unavailable") from exc

    def authorize(self, token: str, request: CIRequest) -> dict[str, Any]:
        claims = self.claims(token)
        policy = read_policy(self.policy_path)  # Reload for revocation; never trust feature checkout.
        build = request.build
        repo = policy["repository"]
        if not re.fullmatch(r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+", repo):
            raise ValidationError("invalid configured repository")
        expected = {
            "repository": repo,
            "repository_id": str(policy["repository_id"]),
            "repository_owner_id": str(policy["repository_owner_id"]),
            "ref": "refs/heads/main",
            "event_name": "workflow_run",
            "runner_environment": "github-hosted",
            "environment": "apktrack-feature-publishing",
            "workflow_ref": f"{repo}/.github/workflows/feature-publish.yml@refs/heads/main",
            "sub": f"repo:{repo}:environment:apktrack-feature-publishing",
        }
        if any(claims.get(key) != value for key, value in expected.items()):
            raise ValidationError("untrusted CI workflow context")
        sha = claims.get("workflow_sha", "")
        if not re.fullmatch(r"[0-9a-f]{40}", sha):
            raise ValidationError("invalid workflow revision")
        workflow = self.get(f"repos/{repo}/contents/.github/workflows/feature-publish.yml?ref={sha}")
        if workflow.get("sha") not in policy["publisher_workflow_blobs"]:
            raise ValidationError("publisher workflow content is not approved")
        for field in ("run_id", "run_attempt", "actor_id"):
            if not re.fullmatch(r"[1-9][0-9]{0,19}", str(claims.get(field, ""))):
                raise ValidationError("invalid CI run identity")
        publisher = self.get(f"repos/{repo}/actions/runs/{claims['run_id']}")
        source = self.get(f"repos/{repo}/actions/runs/{request.source_run_id}")
        if (
            publisher.get("event") != "workflow_run"
            or publisher.get("run_attempt") != int(claims["run_attempt"])
            or publisher.get("head_sha") != sha
            or publisher.get("repository", {}).get("id") != policy["repository_id"]
            or publisher.get("actor", {}).get("id") != int(claims["actor_id"])
        ):
            raise ValidationError("publisher run evidence mismatch")
        if (
            source.get("event") != "push"
            or source.get("conclusion") != "success"
            or source.get("workflow_id") != policy["source_workflow_id"]
            or source.get("head_repository", {}).get("id") != policy["repository_id"]
            or source.get("head_branch") != build.branch
            or source.get("head_sha") != build.commit
            or build.project != policy["project"]
        ):
            raise ValidationError("source build evidence mismatch")
        track, package = feature_identity(policy, build.branch)
        if build.track != track or build.idempotency_key != f"{build.project}-{track}-{build.commit}":
            raise ValidationError("feature identity or idempotency key mismatch")
        for run in (publisher, source):
            for role in ("actor", "triggering_actor"):
                account(policy, run[role], track)
        return {
            "github_repository": repo,
            "github_repository_id": policy["repository_id"],
            "github_actor_id": source["actor"]["id"],
            "developer_npub": account(policy, source["actor"], track),
            "source_run_id": request.source_run_id,
            "source_run_attempt": source["run_attempt"],
            "publisher_run_id": int(claims["run_id"]),
            "publisher_run_attempt": int(claims["run_attempt"]),
            "policy_sha256": hashlib.sha256(json.dumps(policy, sort_keys=True).encode()).hexdigest(),
            "package_name": package,
        }
