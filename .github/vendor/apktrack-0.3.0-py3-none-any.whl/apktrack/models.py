import re
from datetime import UTC, datetime
from enum import StrEnum
from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

HEX64 = re.compile(r"^[0-9a-f]{64}$")
SLUG = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")
TRACK_PATTERN = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,60}[a-z0-9-])?\*$")
PACKAGE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+$")
PACKAGE_PATTERN = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+\.\*$")
COMMIT = re.compile(r"^[0-9a-f]{7,64}$")
BRANCH = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._/-]{0,199}$")


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


def _hex64(value: str) -> str:
    value = value.lower()
    if not HEX64.fullmatch(value):
        raise ValueError("must be 64 lowercase hexadecimal characters")
    return value


def _slug(value: str) -> str:
    if not SLUG.fullmatch(value):
        raise ValueError("must be a lowercase DNS-style slug (1-63 characters)")
    return value


def _branch(value: str) -> str:
    if not BRANCH.fullmatch(value) or ".." in value or "//" in value or value.endswith("/"):
        raise ValueError("must be a safe Git branch or worktree name")
    return value


def package_scopes_overlap(
    first_package: str,
    first_patterns: tuple[str, ...],
    second_package: str,
    second_patterns: tuple[str, ...],
) -> bool:
    """Return whether two exact/prefix Android package allowlists intersect."""
    first_prefixes = tuple(pattern[:-1] for pattern in first_patterns)
    second_prefixes = tuple(pattern[:-1] for pattern in second_patterns)
    return (
        first_package == second_package
        or any(first_package.startswith(prefix) for prefix in second_prefixes)
        or any(second_package.startswith(prefix) for prefix in first_prefixes)
        or any(
            first.startswith(second) or second.startswith(first)
            for first in first_prefixes
            for second in second_prefixes
        )
    )


Sha256 = Annotated[str, Field(pattern=r"^[0-9a-f]{64}$")]
Npub = Annotated[str, Field(pattern=r"^npub1[023456789acdefghjklmnpqrstuvwxyz]{58}$")]


class CertificateRule(StrictModel):
    package_name: str
    package_patterns: tuple[str, ...] = ()
    certificate_sha256: Sha256
    roles: tuple[Literal["production", "development"], ...]
    tracks: tuple[str, ...] = ()
    track_patterns: tuple[str, ...] = ()
    valid_from: int | None = None
    valid_until: int | None = None

    @field_validator("package_name")
    @classmethod
    def package_is_valid(cls, value: str) -> str:
        if not PACKAGE.fullmatch(value):
            raise ValueError("invalid Android package name")
        return value

    @field_validator("package_patterns")
    @classmethod
    def package_patterns_are_valid(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if len(values) != len(set(values)) or any(not PACKAGE_PATTERN.fullmatch(value) for value in values):
            raise ValueError("package patterns must be unique Android namespace prefixes ending in .*")
        return values

    @field_validator("certificate_sha256")
    @classmethod
    def fingerprint_is_valid(cls, value: str) -> str:
        return _hex64(value)

    @field_validator("tracks")
    @classmethod
    def tracks_are_valid(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        return tuple(_slug(value) for value in values)

    @field_validator("track_patterns")
    @classmethod
    def track_patterns_are_valid(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if len(values) != len(set(values)):
            raise ValueError("track patterns must be unique")
        for value in values:
            if not TRACK_PATTERN.fullmatch(value):
                raise ValueError("track patterns must be safe lowercase prefixes ending in *")
        return values

    @model_validator(mode="after")
    def dates_are_ordered(self) -> "CertificateRule":
        if (
            self.valid_from is not None
            and self.valid_until is not None
            and self.valid_until <= self.valid_from
        ):
            raise ValueError("valid_until must be greater than valid_from")
        if not self.roles:
            raise ValueError("at least one role is required")
        return self


class CrossSignature(StrictModel):
    certificate_sha256: Sha256
    certificate_pem: str
    algorithm: Literal["rsa-pkcs1v15-sha256", "ecdsa-sha256", "ed25519"]
    signature_base64: str


class PolicyDocument(StrictModel):
    protocol: Literal["org.apktrack.signing-policy"] = "org.apktrack.signing-policy"
    schema_version: Literal[1, 2] = 1
    project: str
    version: int = Field(ge=1)
    previous_event_id: Sha256 | None = None
    issued_at: int = Field(ge=0)
    valid_from: int | None = None
    valid_until: int | None = None
    certificates: tuple[CertificateRule, ...]
    cross_signatures: tuple[CrossSignature, ...] = ()

    @field_validator("project")
    @classmethod
    def project_is_slug(cls, value: str) -> str:
        return _slug(value)

    @model_validator(mode="after")
    def unique_bindings(self) -> "PolicyDocument":
        pairs = [(x.package_name, x.certificate_sha256) for x in self.certificates]
        if len(pairs) != len(set(pairs)):
            raise ValueError("duplicate package/certificate policy binding")
        if (
            self.valid_from is not None
            and self.valid_until is not None
            and self.valid_until <= self.valid_from
        ):
            raise ValueError("policy valid_until must be greater than valid_from")
        if self.schema_version == 1 and any(
            rule.track_patterns or rule.package_patterns for rule in self.certificates
        ):
            raise ValueError("dynamic package/track patterns require policy schema 2")
        production = [rule for rule in self.certificates if "production" in rule.roles]
        development = [rule for rule in self.certificates if "development" in rule.roles]
        if {rule.certificate_sha256 for rule in production} & {
            rule.certificate_sha256 for rule in development
        }:
            raise ValueError("production and development signing certificates must be distinct")
        if any(
            package_scopes_overlap(
                prod.package_name,
                prod.package_patterns,
                dev.package_name,
                dev.package_patterns,
            )
            for prod in production
            for dev in development
        ):
            raise ValueError("production and development Android package scopes must not overlap")
        return self


class NostrEvent(StrictModel):
    id: Sha256
    pubkey: Sha256
    created_at: int = Field(ge=0)
    kind: int = Field(ge=0)
    tags: tuple[tuple[str, ...], ...]
    content: str
    sig: Annotated[str, Field(pattern=r"^[0-9a-f]{128}$")]


class ApkIdentity(StrictModel):
    package_name: str
    version_name: str = Field(min_length=1, max_length=255)
    version_code: int = Field(ge=0)
    certificate_sha256: Sha256
    signer_count: int = Field(ge=1)
    verified_schemes: tuple[str, ...] = ()


class VerificationResult(StrictModel):
    ok: bool
    checks: dict[str, bool]
    errors: tuple[str, ...] = ()
    apk_sha256: Sha256 | None = None
    identity: ApkIdentity | None = None
    policy_event_id: Sha256 | None = None


class BuildRequest(StrictModel):
    project: str
    track: str
    branch: str
    commit: str
    idempotency_key: str = Field(min_length=8, max_length=128)

    @field_validator("project", "track")
    @classmethod
    def valid_slug(cls, value: str) -> str:
        return _slug(value)

    @field_validator("commit")
    @classmethod
    def valid_commit(cls, value: str) -> str:
        value = value.lower()
        if not COMMIT.fullmatch(value):
            raise ValueError("commit must be 7-64 lowercase hex characters")
        return value

    @field_validator("branch")
    @classmethod
    def valid_branch(cls, value: str) -> str:
        return _branch(value)


class VersionReservation(StrictModel):
    project: str
    track: str
    branch: str
    commit: str
    version_code: int = Field(ge=1)
    idempotency_key: str = Field(min_length=8, max_length=128)
    created_at: int = Field(ge=0)
    claimed_at: int | None = Field(default=None, ge=0)


class JobStatus(StrEnum):
    QUEUED = "queued"
    LEASED = "leased"
    PUBLISHED = "published"
    FAILED = "failed"


class Job(StrictModel):
    id: str
    project: str
    track: str
    branch: str
    commit: str
    candidate_sha256: Sha256
    size: int
    status: JobStatus
    created_at: int
    updated_at: int
    error: str | None = None
    release_sha256: Sha256 | None = None
    submitter_pubkey: Sha256 | None = None
    receipt_delivered: bool = False


class ReleaseMetadata(StrictModel):
    protocol: Literal["org.apktrack.release"] = "org.apktrack.release"
    schema_version: Literal[2] = 2
    project: str
    track: str
    version_name: str = Field(min_length=1, max_length=255)
    version_code: int = Field(ge=0)
    branch: str
    commit: str
    created_at: int = Field(ge=0)
    apk_sha256: Sha256
    apk_size: int = Field(gt=0)
    package_name: str
    certificate_sha256: Sha256
    maintainer_npub: Npub
    installable_alongside_stable: bool
    policy_event_id: Sha256
    policy_version: int = Field(ge=1)
    published_at: int = Field(ge=0)
    verification: Literal["apktrack-verified"] = "apktrack-verified"
    blossom_servers: tuple[str, ...]
    submitter_pubkey: Sha256 | None
    provenance: Literal["submitter-asserted"] = "submitter-asserted"

    @field_validator("project", "track")
    @classmethod
    def release_slugs_are_valid(cls, value: str) -> str:
        return _slug(value)

    @field_validator("branch")
    @classmethod
    def release_branch_is_valid(cls, value: str) -> str:
        return _branch(value)

    @field_validator("commit")
    @classmethod
    def release_commit_is_valid(cls, value: str) -> str:
        value = value.lower()
        if not COMMIT.fullmatch(value):
            raise ValueError("commit must be 7-64 lowercase hex characters")
        return value


class ManifestPath(StrictModel):
    path: str
    sha256: Sha256

    @field_validator("path")
    @classmethod
    def absolute_safe_path(cls, value: str) -> str:
        if not value.startswith("/") or ".." in value.split("/") or "\x00" in value:
            raise ValueError("manifest path must be absolute and traversal-free")
        if value.endswith("/"):
            raise ValueError("manifest path must name a file")
        if "." not in value.rsplit("/", 1)[-1]:
            raise ValueError("NIP-5A manifest path must include a file extension")
        return value


class DashboardRelease(StrictModel):
    project: str
    track: str
    version_name: str
    version_code: int
    branch: str
    commit: str
    sha256: Sha256
    package_name: str
    certificate_sha256: Sha256
    maintainer_npub: str
    installable_alongside_stable: bool
    created_at: int
    published_at: int


def unix_now() -> int:
    return int(datetime.now(UTC).timestamp())
