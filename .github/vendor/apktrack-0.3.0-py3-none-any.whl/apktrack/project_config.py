import tomllib
from pathlib import Path
from typing import Literal

from pydantic import AnyHttpUrl, BaseModel, ConfigDict, Field, WebsocketUrl, field_validator, model_validator

from .models import HEX64, PACKAGE, SLUG, TRACK_PATTERN, PolicyDocument, package_scopes_overlap


class ConfigModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class ProjectSection(ConfigModel):
    name: str = Field(min_length=1, max_length=100)
    slug: str
    description: str = Field(max_length=1000)
    root_pubkey: str
    icon: AnyHttpUrl | Literal[""] = ""

    @field_validator("slug")
    @classmethod
    def valid_slug(cls, value: str) -> str:
        if not SLUG.fullmatch(value):
            raise ValueError("invalid project slug")
        return value

    @field_validator("root_pubkey")
    @classmethod
    def valid_root(cls, value: str) -> str:
        if not HEX64.fullmatch(value):
            raise ValueError("root_pubkey must be 64 lowercase hexadecimal characters")
        return value

    @model_validator(mode="after")
    def public_icon_is_https_without_credentials(self) -> "ProjectSection":
        if self.icon != "" and (
            self.icon.scheme != "https" or self.icon.username is not None or self.icon.password is not None
        ):
            raise ValueError("project icon must use HTTPS without credentials")
        return self


class ServicesSection(ConfigModel):
    profile: Literal["local", "self-hosted", "existing"]
    blossom: tuple[AnyHttpUrl, ...]
    event_servers: tuple[WebsocketUrl, ...]
    nsite_gateway: AnyHttpUrl
    validator_pubkey: str

    @field_validator("validator_pubkey")
    @classmethod
    def valid_validator(cls, value: str) -> str:
        if not HEX64.fullmatch(value):
            raise ValueError("validator_pubkey must be 64 lowercase hexadecimal characters")
        return value

    @model_validator(mode="after")
    def public_services_are_tls_only(self) -> "ServicesSection":
        if any(
            url.scheme != "https" or url.username is not None or url.password is not None
            for url in self.blossom
        ):
            raise ValueError("Blossom URLs must use HTTPS without credentials")
        if any(
            url.scheme != "wss" or url.username is not None or url.password is not None
            for url in self.event_servers
        ):
            raise ValueError("event server URLs must use WSS without credentials")
        if (
            self.nsite_gateway.scheme != "https"
            or self.nsite_gateway.username is not None
            or self.nsite_gateway.password is not None
        ):
            raise ValueError("nsite gateway must use HTTPS without credentials")
        return self


class APKTrackSection(ConfigModel):
    url: AnyHttpUrl
    nsec_env: str = Field(default="APKTRACK_AGENT_NSEC_HEX", pattern=r"^[A-Z][A-Z0-9_]{2,63}$")
    upload_token_env: str = Field(default="APKTRACK_UPLOAD_TOKEN", pattern=r"^[A-Z][A-Z0-9_]{2,63}$")
    build_command: str = Field(min_length=3, max_length=300, pattern=r"^[^\r\n]+$")
    artifact_glob: str = Field(min_length=3, max_length=300)

    @model_validator(mode="after")
    def intake_is_public_https(self) -> "APKTrackSection":
        if self.url.scheme != "https" or self.url.username is not None or self.url.password is not None:
            raise ValueError("APKTrack intake must use HTTPS without credentials")
        return self


class AndroidScopeConfig(ConfigModel):
    role: Literal["production", "development"]
    package: str
    package_patterns: tuple[str, ...] = ()
    certificate_sha256: str
    tracks: tuple[str, ...]
    track_patterns: tuple[str, ...] = ()

    @field_validator("package")
    @classmethod
    def valid_package(cls, value: str) -> str:
        if not PACKAGE.fullmatch(value):
            raise ValueError("invalid Android package name")
        return value

    @field_validator("package_patterns")
    @classmethod
    def valid_package_patterns(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if any(not value.endswith(".*") or not PACKAGE.fullmatch(value[:-2]) for value in values):
            raise ValueError("package patterns must be Android namespace prefixes ending in .*")
        return values

    @field_validator("certificate_sha256")
    @classmethod
    def valid_fingerprint(cls, value: str) -> str:
        if not HEX64.fullmatch(value):
            raise ValueError("certificate fingerprint must be SHA-256 hex")
        return value

    @field_validator("tracks")
    @classmethod
    def valid_tracks(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if not values or any(not SLUG.fullmatch(value) for value in values):
            raise ValueError("at least one valid track is required")
        return values

    @field_validator("track_patterns")
    @classmethod
    def valid_patterns(cls, values: tuple[str, ...]) -> tuple[str, ...]:
        if any(not TRACK_PATTERN.fullmatch(value) for value in values):
            raise ValueError("track patterns must be safe prefixes ending in *")
        return values


class AndroidSection(ConfigModel):
    scope: tuple[AndroidScopeConfig, ...]


class ProjectConfig(ConfigModel):
    schema_version: Literal[2]
    protocol: Literal["org.apktrack.project"]
    project: ProjectSection
    services: ServicesSection
    apktrack: APKTrackSection
    android: AndroidSection

    @model_validator(mode="after")
    def roles_and_tracks_are_unambiguous(self) -> "ProjectConfig":
        roles = {scope.role for scope in self.android.scope}
        if roles != {"production", "development"}:
            raise ValueError("production and development scopes are both required")
        tracks = [track for scope in self.android.scope for track in scope.tracks]
        if len(tracks) != len(set(tracks)):
            raise ValueError("a track may occur in only one Android scope")
        if any(scope.track_patterns for scope in self.android.scope if scope.role == "production"):
            raise ValueError("production scopes cannot use dynamic track patterns")
        if any(scope.package_patterns for scope in self.android.scope if scope.role == "production"):
            raise ValueError("production scopes cannot use dynamic package patterns")
        production = [scope for scope in self.android.scope if scope.role == "production"]
        development = [scope for scope in self.android.scope if scope.role == "development"]
        if {scope.certificate_sha256 for scope in production} & {
            scope.certificate_sha256 for scope in development
        }:
            raise ValueError("production and development signing certificates must be distinct")
        if self.project.root_pubkey == self.services.validator_pubkey:
            raise ValueError("project Root and receipt validator keys must be distinct")
        if any(
            package_scopes_overlap(
                prod.package,
                prod.package_patterns,
                dev.package,
                dev.package_patterns,
            )
            for prod in production
            for dev in development
        ):
            raise ValueError("production and development Android package scopes must not overlap")
        return self


def load_project_config(path: Path) -> ProjectConfig:
    if path.stat().st_size > 64 * 1024:
        raise ValueError("project configuration exceeds 64 KiB")
    with path.open("rb") as stream:
        return ProjectConfig.model_validate(tomllib.load(stream))


def validate_initial_policy(config: ProjectConfig, policy: PolicyDocument) -> None:
    """Require the first trusted policy to encode exactly the reviewed config scopes."""
    if policy.version != 1 or policy.previous_event_id is not None:
        raise ValueError("bootstrap requires an initial policy with version 1 and no predecessor")
    configured = {
        (
            scope.role,
            scope.package,
            frozenset(scope.package_patterns),
            scope.certificate_sha256,
            frozenset(scope.tracks),
            frozenset(scope.track_patterns),
        )
        for scope in config.android.scope
    }
    signed = {
        (
            rule.roles[0] if len(rule.roles) == 1 else "",
            rule.package_name,
            frozenset(rule.package_patterns),
            rule.certificate_sha256,
            frozenset(rule.tracks),
            frozenset(rule.track_patterns),
        )
        for rule in policy.certificates
    }
    if signed != configured:
        raise ValueError("Root-signed policy Android scopes differ from project configuration")


def bootstrap_project(config: ProjectConfig, database: Path, *, dry_run: bool) -> list[str]:
    actions = [f"project {config.project.slug} root={config.project.root_pubkey}"]
    for scope in config.android.scope:
        actions.extend(f"track {track} role={scope.role}" for track in scope.tracks)
    if dry_run:
        return actions
    from .storage import Registry

    registry = Registry(database)
    registry.add_project(
        config.project.slug,
        config.project.root_pubkey,
        "development",
        config.services.validator_pubkey,
    )
    for scope in config.android.scope:
        for track in scope.tracks:
            registry.add_track(
                config.project.slug,
                track,
                scope.role,
                manual_only=scope.role == "production",
                package_name=scope.package,
            )
    return actions
