from typing import cast

from .canonical import canonical_json
from .models import NostrEvent, ReleaseMetadata
from .ports import EventSigner

RELEASE_RECEIPT_KIND = 30382
RELEASE_D_PREFIX = "apktrack-release:"


def receipt_payload(metadata: ReleaseMetadata) -> dict[str, object]:
    content = canonical_json(metadata.model_dump(mode="json")).decode()
    return {
        "created_at": metadata.published_at,
        "kind": RELEASE_RECEIPT_KIND,
        "tags": [
            # Every release needs its own replaceable-event coordinate.  Using
            # one d-tag per track made a relay legitimately replace the
            # previous receipt, which made verified build history impossible.
            [
                "d",
                f"{RELEASE_D_PREFIX}{metadata.project}:{metadata.track}:"
                f"{metadata.version_code}:{metadata.apk_sha256}",
            ],
            ["x", metadata.apk_sha256],
            ["e", metadata.policy_event_id, "policy"],
            ["t", "apktrack-release"],
        ],
        "content": content,
    }


def release_receipt(metadata: ReleaseMetadata, signer: EventSigner) -> NostrEvent:
    payload = receipt_payload(metadata)
    return signer.sign(
        metadata.published_at,
        RELEASE_RECEIPT_KIND,
        cast(list[list[str]], payload["tags"]),
        str(payload["content"]),
    )
