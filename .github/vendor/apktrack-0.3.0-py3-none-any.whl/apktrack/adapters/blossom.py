import base64
import json
import shutil
from pathlib import Path

import httpx

from ..errors import AdapterError
from ..models import unix_now
from ..nostr import event_dict
from ..ports import EventSigner


class BlossomHttpStore:
    def __init__(
        self,
        base_url: str,
        signer: EventSigner,
        timeout: float = 60,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.signer = signer
        self.client = httpx.Client(timeout=timeout, follow_redirects=False)

    def _authorization_payload(self, verb: str, sha256: str) -> bytes:
        now = unix_now()
        host = httpx.URL(self.base_url).host
        tags = [["t", verb], ["x", sha256], ["expiration", str(now + 300)]]
        if host:
            tags.append(["server", host])
        event = self.signer.sign(now - 1, 24242, tags, f"Authorize Blossom {verb}")
        return json.dumps(event_dict(event), separators=(",", ":")).encode()

    @staticmethod
    def _encoded_authorization(payload: bytes, *, legacy: bool = False) -> str:
        if legacy:
            encoded = base64.b64encode(payload).decode()
        else:
            encoded = base64.urlsafe_b64encode(payload).decode().rstrip("=")
        return f"Nostr {encoded}"

    def _authorization(self, verb: str, sha256: str) -> str:
        return self._encoded_authorization(self._authorization_payload(verb, sha256))

    @staticmethod
    def _legacy_auth_retry(response: httpx.Response) -> bool:
        if response.status_code != 400:
            return False
        reason = f"{response.headers.get('x-reason', '')} {response.text}".lower()
        return "base64" in reason or "auth event" in reason

    @staticmethod
    def _response_error(response: httpx.Response) -> str:
        reason = response.headers.get("x-reason") or response.text
        reason = " ".join(reason.split())[:200]
        suffix = f": {reason}" if reason else ""
        return f"HTTP {response.status_code}{suffix}"

    def upload(self, path: Path, sha256: str, content_type: str) -> None:
        payload = self._authorization_payload("upload", sha256)
        headers = {
            "Authorization": self._encoded_authorization(payload),
            "Content-Type": content_type,
            "Content-Length": str(path.stat().st_size),
            "X-SHA-256": sha256,
        }
        try:
            with path.open("rb") as body:
                response = self.client.put(f"{self.base_url}/upload", headers=headers, content=body)
            if self._legacy_auth_retry(response):
                headers["Authorization"] = self._encoded_authorization(payload, legacy=True)
                with path.open("rb") as body:
                    response = self.client.put(f"{self.base_url}/upload", headers=headers, content=body)
        except (OSError, httpx.HTTPError) as exc:
            raise AdapterError(f"Blossom upload failed: {exc}") from exc
        if response.status_code not in {200, 201}:
            raise AdapterError(f"Blossom upload returned {self._response_error(response)}")
        try:
            reported = response.json()["sha256"].lower()
        except (ValueError, KeyError, TypeError) as exc:
            raise AdapterError("Blossom returned an invalid blob descriptor") from exc
        if reported != sha256:
            raise AdapterError("Blossom descriptor hash mismatch")

    def ensure(self, path: Path, sha256: str, content_type: str, expected_size: int) -> tuple[str, ...]:
        if not self.exists(sha256, expected_size):
            self.upload(path, sha256, content_type)
        if not self.exists(sha256, expected_size):
            raise AdapterError("Blossom HEAD did not confirm uploaded blob and size")
        return (self.base_url,)

    def exists(self, sha256: str, expected_size: int) -> bool:
        try:
            response = self.client.head(f"{self.base_url}/{sha256}", follow_redirects=True)
        except httpx.HTTPError as exc:
            raise AdapterError(f"Blossom HEAD failed: {exc}") from exc
        if response.status_code == 404:
            return False
        if response.status_code != 200:
            raise AdapterError(f"Blossom HEAD returned HTTP {response.status_code}")
        if any(sha256 not in str(item.headers.get("location", "")) for item in response.history):
            raise AdapterError("Blossom redirected HEAD to a URL without the requested hash")
        length = response.headers.get("content-length")
        return length is not None and int(length) == expected_size

    def delete(self, sha256: str) -> None:
        payload = self._authorization_payload("delete", sha256)
        headers = {"Authorization": self._encoded_authorization(payload)}
        try:
            response = self.client.delete(f"{self.base_url}/{sha256}", headers=headers)
            if self._legacy_auth_retry(response):
                headers["Authorization"] = self._encoded_authorization(payload, legacy=True)
                response = self.client.delete(f"{self.base_url}/{sha256}", headers=headers)
        except httpx.HTTPError as exc:
            raise AdapterError(f"Blossom DELETE failed: {exc}") from exc
        if response.status_code not in {200, 202, 204, 404}:
            raise AdapterError(f"Blossom DELETE returned {self._response_error(response)}")


class MemoryBlobStore:
    def __init__(self) -> None:
        self.blobs: dict[str, bytes] = {}
        self.deleted: list[str] = []

    def upload(self, path: Path, sha256: str, content_type: str) -> None:
        del content_type
        self.blobs[sha256] = path.read_bytes()

    def ensure(self, path: Path, sha256: str, content_type: str, expected_size: int) -> tuple[str, ...]:
        if not self.exists(sha256, expected_size):
            self.upload(path, sha256, content_type)
        return ()

    def exists(self, sha256: str, expected_size: int) -> bool:
        return sha256 in self.blobs and len(self.blobs[sha256]) == expected_size

    def delete(self, sha256: str) -> None:
        self.blobs.pop(sha256, None)
        self.deleted.append(sha256)


class LocalBlobStore:
    """Content-addressed local development adapter; never talks to a live server."""

    def __init__(self, directory: Path) -> None:
        self.directory = directory
        self.directory.mkdir(parents=True, exist_ok=True)

    def upload(self, path: Path, sha256: str, content_type: str) -> None:
        del content_type
        destination = self.directory / sha256
        if not destination.exists():
            shutil.copyfile(path, destination)

    def ensure(self, path: Path, sha256: str, content_type: str, expected_size: int) -> tuple[str, ...]:
        if not self.exists(sha256, expected_size):
            self.upload(path, sha256, content_type)
        return ()

    def exists(self, sha256: str, expected_size: int) -> bool:
        path = self.directory / sha256
        return path.is_file() and path.stat().st_size == expected_size

    def delete(self, sha256: str) -> None:
        (self.directory / sha256).unlink(missing_ok=True)


class ReplicatedBlossomStore:
    """Best-effort replication that advertises only confirmed locations."""

    def __init__(self, stores: tuple[BlossomHttpStore, ...]) -> None:
        if not stores:
            raise ValueError("at least one Blossom store is required")
        self.stores = stores

    def ensure(self, path: Path, sha256: str, content_type: str, expected_size: int) -> tuple[str, ...]:
        available: list[str] = []
        errors: list[str] = []
        for store in self.stores:
            try:
                available.extend(store.ensure(path, sha256, content_type, expected_size))
            except AdapterError as exc:
                errors.append(f"{store.base_url}: {exc}")
        if not available:
            raise AdapterError("Blossom replication failed on every server: " + "; ".join(errors))
        return tuple(available)

    def upload(self, path: Path, sha256: str, content_type: str) -> None:
        self.ensure(path, sha256, content_type, path.stat().st_size)

    def exists(self, sha256: str, expected_size: int) -> bool:
        for store in self.stores:
            try:
                if store.exists(sha256, expected_size):
                    return True
            except AdapterError:
                continue
        return False

    def delete(self, sha256: str) -> None:
        succeeded = False
        errors: list[str] = []
        for store in self.stores:
            try:
                store.delete(sha256)
                succeeded = True
            except AdapterError as exc:
                errors.append(f"{store.base_url}: {exc}")
        if not succeeded:
            raise AdapterError("Blossom deletion failed on every server: " + "; ".join(errors))
