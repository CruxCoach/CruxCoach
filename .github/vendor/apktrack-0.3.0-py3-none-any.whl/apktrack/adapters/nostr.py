import asyncio
import json
import os
import secrets
import subprocess
from pathlib import Path

from ..errors import AdapterError
from ..models import NostrEvent
from ..nostr import event_dict, sign_event, verify_event
from ..ports import EventNetwork


class EnvironmentNostrSigner:
    """Operational signer loaded only from a named environment variable."""

    def __init__(self, environment_variable: str = "APKTRACK_OPERATIONAL_NSEC_HEX") -> None:
        self.environment_variable = environment_variable

    def _secret(self) -> str:
        value = os.environ.get(self.environment_variable)
        if value is None:
            raise AdapterError(f"signing secret is unavailable in {self.environment_variable}")
        if len(value) != 64:
            raise AdapterError("operational signer expects a 32-byte hex secret")
        return value

    @property
    def pubkey(self) -> str:
        return sign_event(self._secret(), 0, 1, [], "").pubkey

    def sign(self, created_at: int, kind: int, tags: list[list[str]], content: str) -> NostrEvent:
        return sign_event(self._secret(), created_at, kind, tags, content)


class FileNostrSigner:
    """Signer backed by a mode-0600 credential file, suitable for systemd credentials."""

    def __init__(self, path: Path) -> None:
        self.path = path

    def _secret(self) -> str:
        value = self.path.read_text().strip()
        if len(value) != 64:
            raise AdapterError("file signer expects a 32-byte hex secret")
        try:
            bytes.fromhex(value)
        except ValueError as exc:
            raise AdapterError("file signer contains invalid hexadecimal data") from exc
        return value

    @property
    def pubkey(self) -> str:
        return sign_event(self._secret(), 0, 1, [], "").pubkey

    def sign(self, created_at: int, kind: int, tags: list[list[str]], content: str) -> NostrEvent:
        return sign_event(self._secret(), created_at, kind, tags, content)


class EphemeralNostrSigner:
    """Process-local development signer; identity intentionally changes on restart."""

    def __init__(self) -> None:
        self.__secret = secrets.token_hex(32)

    @property
    def pubkey(self) -> str:
        return sign_event(self.__secret, 0, 1, [], "").pubkey

    def sign(self, created_at: int, kind: int, tags: list[list[str]], content: str) -> NostrEvent:
        return sign_event(self.__secret, created_at, kind, tags, content)


class CommandEventSigner:
    """Secretless process adapter suitable for an operator-owned signer/HSM bridge."""

    def __init__(self, command: list[str]) -> None:
        if not command:
            raise ValueError("event signer command is empty")
        self.command = command

    def _run(self, action: str, payload: str = "") -> str:
        try:
            result = subprocess.run(
                [*self.command, action],
                input=payload,
                text=True,
                capture_output=True,
                check=True,
                timeout=120,
            )
        except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            raise AdapterError(f"command event signer failed: {exc}") from exc
        return result.stdout.strip()

    @property
    def pubkey(self) -> str:
        value = self._run("get-public-key").lower()
        if len(value) != 64:
            raise AdapterError("command signer returned an invalid public key")
        return value

    def sign(self, created_at: int, kind: int, tags: list[list[str]], content: str) -> NostrEvent:
        request = json.dumps(
            {"created_at": created_at, "kind": kind, "tags": tags, "content": content},
            separators=(",", ":"),
        )
        try:
            event = NostrEvent.model_validate_json(self._run("sign-event", request))
        except ValueError as exc:
            raise AdapterError(f"command signer returned an invalid event: {exc}") from exc
        if (
            event.created_at != created_at
            or event.kind != kind
            or event.tags != tuple(tuple(tag) for tag in tags)
            or event.content != content
            or event.pubkey != self.pubkey
            or not verify_event(event)
        ):
            raise AdapterError("command signer changed the request or returned an invalid signature")
        return event


class WebSocketEventNetwork:
    def __init__(self, url: str, timeout: float = 15) -> None:
        self.url = url
        self.timeout = timeout

    def publish(self, event: NostrEvent) -> None:
        asyncio.run(self._publish(event))

    async def _publish(self, event: NostrEvent) -> None:
        import websockets

        try:
            async with websockets.connect(self.url, open_timeout=self.timeout) as socket:
                await socket.send(json.dumps(["EVENT", event_dict(event)], separators=(",", ":")))
                while True:
                    raw = await asyncio.wait_for(socket.recv(), timeout=self.timeout)
                    message = json.loads(raw)
                    if message[0] == "OK" and message[1] == event.id:
                        if message[2] is not True:
                            raise AdapterError(f"event network rejected event: {message[3]}")
                        break

                subscription = secrets.token_hex(8)
                await socket.send(
                    json.dumps(
                        ["REQ", subscription, {"ids": [event.id], "limit": 1}],
                        separators=(",", ":"),
                    )
                )
                while True:
                    raw = await asyncio.wait_for(socket.recv(), timeout=self.timeout)
                    message = json.loads(raw)
                    if message[0] == "EVENT" and message[1] == subscription:
                        returned = NostrEvent.model_validate(message[2])
                        if returned.id == event.id and verify_event(returned):
                            await socket.send(json.dumps(["CLOSE", subscription]))
                            return
                    if message[0] == "EOSE" and message[1] == subscription:
                        raise AdapterError("event network accepted the event but did not persist it")
        except AdapterError:
            raise
        except (OSError, TimeoutError, ValueError) as exc:
            raise AdapterError(f"event network publish failed: {exc}") from exc


class ReplicatedEventNetwork:
    """Require every configured relay to persist an event before delivery succeeds."""

    def __init__(self, networks: tuple[EventNetwork, ...]) -> None:
        if len(networks) < 2:
            raise ValueError("replicated event network requires at least two relays")
        self.networks = networks

    def publish(self, event: NostrEvent) -> None:
        failures: list[str] = []
        for network in self.networks:
            try:
                network.publish(event)
            except Exception as exc:
                failures.append(str(exc))
        if failures:
            raise AdapterError(f"event replication failed on {len(failures)} of {len(self.networks)} relays")


class MemoryEventNetwork:
    def __init__(self) -> None:
        self.events: list[NostrEvent] = []

    def publish(self, event: NostrEvent) -> None:
        self.events.append(event)
