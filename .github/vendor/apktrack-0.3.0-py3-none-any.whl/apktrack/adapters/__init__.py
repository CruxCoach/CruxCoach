"""External protocol adapters."""
