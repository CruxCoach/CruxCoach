import hmac
from pathlib import Path

from .canonical import sha256_file
from .errors import ValidationError
from .models import NostrEvent, VerificationResult, unix_now
from .policy import authorize_apk, package_is_allowed, parse_and_verify_policy_event, verify_cross_signatures
from .ports import ApkInspector


def verify_release(
    apk: Path,
    expected_sha256: str,
    policy_event: NostrEvent,
    trusted_root: str,
    project: str,
    track: str,
    role: str,
    inspector: ApkInspector,
    now: int | None = None,
) -> VerificationResult:
    checks = {
        "final_sha256": False,
        "nostr_policy_signature": False,
        "latest_policy": True,
        "apk_signature": False,
        "certificate_fingerprint": False,
        "package_name": False,
        "policy_scope": False,
        "cross_signature": True,
    }
    errors: list[str] = []
    actual_hash, _ = sha256_file(str(apk))
    checks["final_sha256"] = hmac.compare_digest(actual_hash, expected_sha256)
    if not checks["final_sha256"]:
        errors.append("final APK SHA-256 does not match expected digest")
    try:
        policy = parse_and_verify_policy_event(policy_event, trusted_root, project)
        checks["nostr_policy_signature"] = True
    except ValidationError as exc:
        errors.append(str(exc))
        return VerificationResult(
            ok=False,
            checks=checks,
            errors=tuple(errors),
            apk_sha256=actual_hash,
            policy_event_id=policy_event.id,
        )
    cross_errors = verify_cross_signatures(policy)
    if cross_errors:
        checks["cross_signature"] = False
        errors.extend(cross_errors)
    try:
        identity = inspector.inspect(apk)
        checks["apk_signature"] = True
    except Exception as exc:
        errors.append(f"APK signature/identity inspection failed: {exc}")
        return VerificationResult(
            ok=False,
            checks=checks,
            errors=tuple(errors),
            apk_sha256=actual_hash,
            policy_event_id=policy_event.id,
        )
    matching_package = [
        rule
        for rule in policy.certificates
        if package_is_allowed(rule.package_name, rule.package_patterns, identity.package_name)
    ]
    checks["package_name"] = bool(matching_package)
    checks["certificate_fingerprint"] = any(
        hmac.compare_digest(rule.certificate_sha256, identity.certificate_sha256) for rule in matching_package
    )
    try:
        authorize_apk(policy, identity, track, role, now or unix_now())
        checks["policy_scope"] = True
    except ValidationError as exc:
        errors.append(str(exc))
    return VerificationResult(
        ok=all(checks.values()),
        checks=checks,
        errors=tuple(errors),
        apk_sha256=actual_hash,
        identity=identity,
        policy_event_id=policy_event.id,
    )


def select_latest_policy(events: list[NostrEvent], trusted_root: str, project: str) -> NostrEvent:
    """Validate a complete, contiguous local policy history and return its tip."""
    parsed = [(event, parse_and_verify_policy_event(event, trusted_root, project)) for event in events]
    parsed.sort(key=lambda pair: pair[1].version)
    if not parsed or parsed[0][1].version != 1 or parsed[0][1].previous_event_id is not None:
        raise ValidationError("policy bundle must start with version 1")
    previous = parsed[0][0]
    for event, policy in parsed[1:]:
        previous_policy = next(value for candidate, value in parsed if candidate.id == previous.id)
        if policy.version != previous_policy.version + 1 or policy.previous_event_id != previous.id:
            raise ValidationError("policy bundle is not a contiguous predecessor chain")
        previous = event
    return previous
