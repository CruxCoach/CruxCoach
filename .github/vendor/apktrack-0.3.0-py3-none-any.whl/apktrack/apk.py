import re
import subprocess
from pathlib import Path

from .errors import AdapterError, ValidationError
from .models import ApkIdentity

CERT_LINE = re.compile(r"Signer #\d+ certificate SHA-256 digest: ([0-9a-fA-F:]{64,95})")
PACKAGE_LINE = re.compile(
    r"^package: name='(?P<package>[^']+)' versionCode='(?P<code>[0-9]+)' "
    r"versionName='(?P<name>[^']+)'",
    re.MULTILINE,
)


class AndroidSdkApkInspector:
    """Official Android tool adapter: apksigner verifies signatures, aapt reads package."""

    def __init__(self, apksigner: str = "apksigner", aapt: str = "aapt") -> None:
        self.apksigner = apksigner
        self.aapt = aapt

    def inspect(self, apk: Path) -> ApkIdentity:
        verify = self._run([self.apksigner, "verify", "--verbose", "--print-certs", "--Werr", str(apk)])
        fingerprints = {match.group(1).replace(":", "").lower() for match in CERT_LINE.finditer(verify)}
        if len(fingerprints) != 1:
            raise ValidationError(
                "MVP accepts exactly one unique current signer certificate; "
                f"apksigner reported {len(fingerprints)}"
            )
        schemes = tuple(
            scheme
            for scheme, marker in (
                ("v1", "Verified using v1 scheme (JAR signing): true"),
                ("v2", "Verified using v2 scheme (APK Signature Scheme v2): true"),
                ("v3", "Verified using v3 scheme (APK Signature Scheme v3): true"),
                ("v4", "Verified using v4 scheme (APK Signature Scheme v4): true"),
            )
            if marker in verify
        )
        badging = self._run([self.aapt, "dump", "badging", str(apk)])
        package_match = PACKAGE_LINE.search(badging)
        if package_match is None:
            raise AdapterError("aapt did not report an Android package name")
        return ApkIdentity(
            package_name=package_match.group("package"),
            version_name=package_match.group("name"),
            version_code=int(package_match.group("code")),
            certificate_sha256=next(iter(fingerprints)),
            signer_count=1,
            verified_schemes=schemes,
        )

    def _run(self, command: list[str]) -> str:
        try:
            result = subprocess.run(
                command,
                check=False,
                capture_output=True,
                text=True,
                timeout=120,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            raise AdapterError(f"Android SDK tool failed: {command[0]}: {exc}") from exc
        output = result.stdout + result.stderr
        if result.returncode != 0:
            message = output[-2000:].strip()
            raise ValidationError(f"APK verification failed ({command[0]}): {message}")
        return output


class AndroidSdkApkSigner:
    """Adapter for a local/HSM wrapper; passwords are environment indirections only."""

    def __init__(self, command: list[str]) -> None:
        if not command:
            raise ValueError("signer command is empty")
        self.command = command

    def sign(self, source: Path, destination: Path, profile: str) -> None:
        command = [*self.command, "--profile", profile, "--in", str(source), "--out", str(destination)]
        try:
            subprocess.run(command, check=True, timeout=300)
        except (OSError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
            raise AdapterError(f"external APK signer failed: {exc}") from exc
