import hashlib
import json
import secrets
import sqlite3
import threading
import uuid
from collections.abc import Callable, Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any, cast

from . import ci_grants
from .errors import ConflictError, NotFoundError
from .models import (
    TRACK_PATTERN,
    BuildRequest,
    Job,
    JobStatus,
    ManifestPath,
    NostrEvent,
    PolicyDocument,
    VersionReservation,
    unix_now,
)

SCHEMA = """
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS projects (
  slug TEXT PRIMARY KEY,
  root_identity TEXT NOT NULL,
  validator_identity TEXT,
  development_signer_profile TEXT,
  default_role TEXT NOT NULL CHECK(default_role IN ('production','development')),
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS api_tokens (
  id TEXT PRIMARY KEY,
  project TEXT NOT NULL REFERENCES projects(slug),
  track TEXT,
  salt BLOB NOT NULL,
  digest BLOB NOT NULL,
  disabled INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tracks (
  project TEXT NOT NULL REFERENCES projects(slug),
  slug TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('production','development')),
  manual_only INTEGER NOT NULL DEFAULT 0,
  signer_profile TEXT,
  package_name TEXT,
  source_branch TEXT,
  PRIMARY KEY(project,slug)
);
CREATE TABLE IF NOT EXISTS policies (
  event_id TEXT PRIMARY KEY,
  project TEXT NOT NULL REFERENCES projects(slug),
  version INTEGER NOT NULL,
  created_at INTEGER NOT NULL,
  event_json TEXT NOT NULL,
  policy_json TEXT NOT NULL,
  UNIQUE(project, version)
);
CREATE TABLE IF NOT EXISTS blobs (
  sha256 TEXT PRIMARY KEY,
  size INTEGER NOT NULL,
  manifest_refs INTEGER NOT NULL DEFAULT 0 CHECK(manifest_refs >= 0),
  job_refs INTEGER NOT NULL DEFAULT 0 CHECK(job_refs >= 0),
  release_refs INTEGER NOT NULL DEFAULT 0 CHECK(release_refs >= 0),
  uploaded INTEGER NOT NULL DEFAULT 0,
  unreferenced_at INTEGER
);
CREATE TABLE IF NOT EXISTS jobs (
  id TEXT PRIMARY KEY,
  project TEXT NOT NULL REFERENCES projects(slug),
  track TEXT NOT NULL,
  branch TEXT NOT NULL,
  commit_hash TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  candidate_sha256 TEXT NOT NULL REFERENCES blobs(sha256),
  candidate_path TEXT NOT NULL,
  size INTEGER NOT NULL,
  status TEXT NOT NULL,
  lease_owner TEXT,
  lease_until INTEGER,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL,
  error TEXT,
  release_sha256 TEXT,
  submitter_pubkey TEXT,
  UNIQUE(project, idempotency_key)
);
CREATE TABLE IF NOT EXISTS manifest_paths (
  path TEXT PRIMARY KEY,
  sha256 TEXT NOT NULL REFERENCES blobs(sha256),
  project TEXT NOT NULL,
  track TEXT NOT NULL,
  content_type TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS releases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  project TEXT NOT NULL,
  track TEXT NOT NULL,
  version_name TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  branch TEXT NOT NULL,
  commit_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  apk_sha256 TEXT NOT NULL,
  metadata_sha256 TEXT NOT NULL,
  package_name TEXT NOT NULL,
  certificate_sha256 TEXT NOT NULL,
  maintainer_npub TEXT NOT NULL,
  installable_alongside_stable INTEGER NOT NULL,
  policy_event_id TEXT NOT NULL,
  published_at INTEGER NOT NULL,
  receipt_event_id TEXT,
  receipt_event_json TEXT,
  blossom_servers_json TEXT
);
CREATE TABLE IF NOT EXISTS version_reservations (
  project TEXT NOT NULL REFERENCES projects(slug),
  track TEXT NOT NULL,
  branch TEXT NOT NULL,
  commit_hash TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  version_code INTEGER NOT NULL CHECK(version_code > 0),
  created_at INTEGER NOT NULL,
  claimed_at INTEGER,
  PRIMARY KEY(project,track,version_code),
  UNIQUE(project,idempotency_key),
  UNIQUE(project,track,commit_hash)
);
CREATE TABLE IF NOT EXISTS receipt_outbox (
  event_id TEXT PRIMARY KEY,
  event_json TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  delivered_at INTEGER
);
CREATE TABLE IF NOT EXISTS outbox (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  aggregate_hash TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  delivered_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON jobs(status, created_at);
CREATE INDEX IF NOT EXISTS idx_blobs_gc ON blobs(manifest_refs, job_refs, release_refs, unreferenced_at);
CREATE INDEX IF NOT EXISTS idx_version_reservations_lookup
  ON version_reservations(project,track,commit_hash);
"""


class Registry:
    def __init__(self, database: Path) -> None:
        database.parent.mkdir(parents=True, exist_ok=True)
        self.database = database
        self._write_lock = threading.RLock()
        with self.connect() as connection:
            connection.executescript(SCHEMA + ci_grants.SCHEMA)
            self._migrate(connection)
            connection.execute("PRAGMA journal_mode=WAL")

    @staticmethod
    def _migrate(connection: sqlite3.Connection) -> None:
        project_columns = {row["name"] for row in connection.execute("PRAGMA table_info(projects)")}
        if "validator_identity" not in project_columns:
            connection.execute("ALTER TABLE projects ADD COLUMN validator_identity TEXT")
        if "development_signer_profile" not in project_columns:
            connection.execute("ALTER TABLE projects ADD COLUMN development_signer_profile TEXT")
        blob_columns = {row["name"] for row in connection.execute("PRAGMA table_info(blobs)")}
        if "release_refs" not in blob_columns:
            connection.execute("ALTER TABLE blobs ADD COLUMN release_refs INTEGER NOT NULL DEFAULT 0")
        job_columns = {row["name"] for row in connection.execute("PRAGMA table_info(jobs)")}
        if "submitter_pubkey" not in job_columns:
            connection.execute("ALTER TABLE jobs ADD COLUMN submitter_pubkey TEXT")
        track_columns = {row["name"] for row in connection.execute("PRAGMA table_info(tracks)")}
        if "package_name" not in track_columns:
            connection.execute("ALTER TABLE tracks ADD COLUMN package_name TEXT")
        if "source_branch" not in track_columns:
            connection.execute("ALTER TABLE tracks ADD COLUMN source_branch TEXT")
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS idx_tracks_source_branch "
            "ON tracks(project,source_branch) WHERE source_branch IS NOT NULL"
        )
        connection.execute(
            "UPDATE tracks SET package_name=(SELECT r.package_name FROM releases r "
            "WHERE r.project=tracks.project AND r.track=tracks.slug "
            "ORDER BY r.id DESC LIMIT 1) WHERE package_name IS NULL"
        )
        release_columns = {row["name"] for row in connection.execute("PRAGMA table_info(releases)")}
        for name, sql_type in (
            ("receipt_event_id", "TEXT"),
            ("receipt_event_json", "TEXT"),
            ("blossom_servers_json", "TEXT"),
        ):
            if name not in release_columns:
                connection.execute(f"ALTER TABLE releases ADD COLUMN {name} {sql_type}")
        connection.execute(
            "CREATE TABLE IF NOT EXISTS receipt_outbox (event_id TEXT PRIMARY KEY, "
            "event_json TEXT NOT NULL, created_at INTEGER NOT NULL, delivered_at INTEGER)"
        )
        connection.execute("UPDATE blobs SET release_refs=0")
        connection.execute(
            "UPDATE blobs SET release_refs=(SELECT COUNT(*) FROM releases r WHERE r.apk_sha256=blobs.sha256)"
        )

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.database, timeout=30, isolation_level=None)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA busy_timeout=30000")
        return connection

    @contextmanager
    def transaction(self) -> Iterator[sqlite3.Connection]:
        with self._write_lock, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                yield connection
            except Exception:
                connection.rollback()
                raise
            else:
                connection.commit()

    def add_project(
        self,
        slug: str,
        root_identity: str,
        default_role: str,
        validator_identity: str | None = None,
        development_signer_profile: str | None = None,
    ) -> None:
        with self.transaction() as db:
            db.execute(
                "INSERT INTO projects(slug,root_identity,validator_identity,development_signer_profile,"
                "default_role,created_at) VALUES(?,?,?,?,?,?) "
                "ON CONFLICT(slug) DO UPDATE SET root_identity=excluded.root_identity, "
                "validator_identity=COALESCE(excluded.validator_identity,projects.validator_identity), "
                "development_signer_profile=COALESCE(excluded.development_signer_profile,"
                "projects.development_signer_profile), "
                "default_role=excluded.default_role",
                (
                    slug,
                    root_identity,
                    validator_identity,
                    development_signer_profile,
                    default_role,
                    unix_now(),
                ),
            )

    def set_development_signer_profile(self, project: str, profile: str) -> None:
        if not profile or len(profile) > 100 or any(character.isspace() for character in profile):
            raise ConflictError("development signer profile must be a non-empty token")
        with self.transaction() as db:
            result = db.execute(
                "UPDATE projects SET development_signer_profile=? WHERE slug=?", (profile, project)
            )
            if result.rowcount != 1:
                raise NotFoundError(f"unknown project: {project}")

    def project(self, slug: str) -> sqlite3.Row:
        with self.connect() as db:
            row = db.execute("SELECT * FROM projects WHERE slug=?", (slug,)).fetchone()
        if row is None:
            raise NotFoundError(f"unknown project: {slug}")
        return cast(sqlite3.Row, row)

    def add_track(
        self,
        project: str,
        slug: str,
        role: str,
        manual_only: bool,
        signer_profile: str | None = None,
        package_name: str | None = None,
        source_branch: str | None = None,
    ) -> None:
        self.project(project)
        with self.transaction() as db:
            db.execute(
                "INSERT INTO tracks(project,slug,role,manual_only,signer_profile,package_name,source_branch) "
                "VALUES(?,?,?,?,?,?,?) "
                "ON CONFLICT(project,slug) DO UPDATE SET role=excluded.role,"
                "manual_only=excluded.manual_only,signer_profile=excluded.signer_profile,"
                "package_name=COALESCE(excluded.package_name,tracks.package_name),"
                "source_branch=COALESCE(excluded.source_branch,tracks.source_branch)",
                (project, slug, role, int(manual_only), signer_profile, package_name, source_branch),
            )

    def bind_track_identity(
        self,
        project: str,
        track: str,
        package_name: str,
        source_branch: str,
        *,
        provision_role: str | None = None,
        provision_signer_profile: str | None = None,
    ) -> None:
        """Atomically bind one publication stream to one package and source branch."""
        with self.transaction() as db:
            configured = db.execute(
                "SELECT * FROM tracks WHERE project=? AND slug=?", (project, track)
            ).fetchone()
            if configured is None:
                if provision_role != "development":
                    raise ConflictError("unknown tracks require an authorized development provision")
                try:
                    db.execute(
                        "INSERT INTO tracks(project,slug,role,manual_only,signer_profile,"
                        "package_name,source_branch) VALUES(?,?,?,0,?,?,?)",
                        (
                            project,
                            track,
                            provision_role,
                            provision_signer_profile,
                            package_name,
                            source_branch,
                        ),
                    )
                except sqlite3.IntegrityError as exc:
                    raise ConflictError("source branch is already bound to another track") from exc
                return
            expected_package = configured["package_name"]
            expected_branch = configured["source_branch"]
            if expected_package is not None and expected_package != package_name:
                raise ConflictError("track is permanently bound to another Android package")
            if expected_branch is not None and expected_branch != source_branch:
                raise ConflictError("track is permanently bound to another source branch")
            try:
                db.execute(
                    "UPDATE tracks SET package_name=COALESCE(package_name,?),"
                    "source_branch=COALESCE(source_branch,?) WHERE project=? AND slug=?",
                    (package_name, source_branch, project, track),
                )
            except sqlite3.IntegrityError as exc:
                raise ConflictError("source branch is already bound to another track") from exc

    def track(self, project: str, slug: str) -> sqlite3.Row:
        with self.connect() as db:
            row = db.execute("SELECT * FROM tracks WHERE project=? AND slug=?", (project, slug)).fetchone()
        if row is None:
            raise NotFoundError(f"unknown track: {project}/{slug}")
        return cast(sqlite3.Row, row)

    def create_token(self, project: str, track: str | None) -> tuple[str, str]:
        self.project(project)
        if track is not None:
            self._require_development_upload_scope(project, track)
        identifier = uuid.uuid4().hex
        secret = secrets.token_urlsafe(32)
        salt = secrets.token_bytes(16)
        digest = _token_digest(secret, salt)
        with self.transaction() as db:
            db.execute(
                "INSERT INTO api_tokens(id,project,track,salt,digest,created_at) VALUES(?,?,?,?,?,?)",
                (identifier, project, track, salt, digest, unix_now()),
            )
        return identifier, f"{identifier}.{secret}"

    def _require_development_upload_scope(self, project: str, scope: str) -> None:
        if scope.endswith("*"):
            if not TRACK_PATTERN.fullmatch(scope):
                raise ConflictError("upload token pattern must be a safe lowercase prefix ending in *")
            _event, policy = self.latest_policy(project)
            if not any(
                "development" in rule.roles and scope in rule.track_patterns for rule in policy.certificates
            ):
                raise ConflictError("upload token pattern is not authorized by the current Root policy")
            return
        try:
            track = self.track(project, scope)
        except NotFoundError:
            _event, policy = self.latest_policy(project)
            if any(
                "development" in rule.roles
                and any(scope.startswith(pattern[:-1]) for pattern in rule.track_patterns)
                for rule in policy.certificates
            ):
                return
            raise ConflictError("upload token track is unknown or not development-authorized") from None
        if track["role"] != "development" or bool(track["manual_only"]):
            raise ConflictError("upload tokens cannot authorize production or manual-only tracks")

    def remote_upload_allowed(self, project: str, track: str) -> bool:
        """Admit only known development tracks or Root-authorized dynamic development tracks."""
        try:
            configured = self.track(project, track)
        except NotFoundError:
            try:
                _event, policy = self.latest_policy(project)
            except NotFoundError:
                return False
            return any(
                "development" in rule.roles
                and any(track.startswith(pattern[:-1]) for pattern in rule.track_patterns)
                for rule in policy.certificates
            )
        return configured["role"] == "development" and not bool(configured["manual_only"])

    def authenticate(self, token: str, project: str, track: str) -> bool:
        identifier, separator, secret = token.partition(".")
        if not separator or not identifier or not secret:
            _token_digest("invalid", b"\0" * 16)
            return False
        with self.connect() as db:
            row = db.execute("SELECT * FROM api_tokens WHERE id=? AND disabled=0", (identifier,)).fetchone()
        if row is None:
            _token_digest(secret, b"\0" * 16)
            return False
        actual = _token_digest(secret, bytes(row["salt"]))
        return (
            secrets.compare_digest(actual, bytes(row["digest"]))
            and secrets.compare_digest(str(row["project"]), project)
            and (
                row["track"] is None
                or secrets.compare_digest(str(row["track"]), track)
                or (str(row["track"]).endswith("*") and track.startswith(str(row["track"])[:-1]))
            )
        )

    def reserve_development_version(
        self,
        project: str,
        track: str,
        branch: str,
        commit: str,
        idempotency_key: str,
        minimum: int,
    ) -> VersionReservation:
        """Atomically allocate one development-track version code."""
        now = unix_now()
        with self.transaction() as db:
            existing = db.execute(
                "SELECT * FROM version_reservations WHERE project=? AND idempotency_key=?",
                (project, idempotency_key),
            ).fetchone()
            if existing is not None:
                if (
                    existing["track"] != track
                    or existing["branch"] != branch
                    or existing["commit_hash"] != commit
                ):
                    raise ConflictError("version reservation idempotency key was reused")
                return _version_reservation(existing)
            same_commit = db.execute(
                "SELECT * FROM version_reservations WHERE project=? AND track=? AND commit_hash=?",
                (project, track, commit),
            ).fetchone()
            if same_commit is not None:
                if same_commit["branch"] != branch:
                    raise ConflictError("version reservation commit changed source branch")
                return _version_reservation(same_commit)
            latest_release = db.execute(
                "SELECT MAX(version_code) AS value FROM releases WHERE project=? AND track=?",
                (project, track),
            ).fetchone()
            latest_reservation = db.execute(
                "SELECT MAX(version_code) AS value FROM version_reservations WHERE project=? AND track=?",
                (project, track),
            ).fetchone()
            previous = max(
                int(latest_release["value"] or 0),
                int(latest_reservation["value"] or 0),
                minimum - 1,
            )
            version_code = previous + 1
            db.execute(
                "INSERT INTO version_reservations(project,track,branch,commit_hash,"
                "idempotency_key,version_code,created_at) VALUES(?,?,?,?,?,?,?)",
                (project, track, branch, commit, idempotency_key, version_code, now),
            )
            row = db.execute(
                "SELECT * FROM version_reservations WHERE project=? AND track=? AND version_code=?",
                (project, track, version_code),
            ).fetchone()
        assert row is not None
        return _version_reservation(row)

    def version_reservation(self, project: str, track: str, commit: str) -> VersionReservation:
        with self.connect() as db:
            row = db.execute(
                "SELECT * FROM version_reservations WHERE project=? AND track=? AND commit_hash=?",
                (project, track, commit),
            ).fetchone()
        if row is None:
            raise NotFoundError("version reservation not found")
        return _version_reservation(row)

    def disable_token(self, identifier: str) -> None:
        with self.transaction() as db:
            result = db.execute("UPDATE api_tokens SET disabled=1 WHERE id=?", (identifier,))
            if result.rowcount != 1:
                raise NotFoundError("upload token not found")

    def store_policy(self, project: str, event: NostrEvent, policy: PolicyDocument) -> None:
        with self.transaction() as db:
            latest = db.execute(
                "SELECT event_id,version FROM policies WHERE project=? ORDER BY version DESC LIMIT 1",
                (project,),
            ).fetchone()
            if latest is not None and latest["event_id"] == event.id:
                return
            if latest is None:
                if policy.version != 1 or policy.previous_event_id is not None:
                    raise ConflictError("first policy must be version 1 without predecessor")
            else:
                if policy.version != int(latest["version"]) + 1:
                    raise ConflictError("policy version must increment exactly by one")
                if policy.previous_event_id != latest["event_id"]:
                    raise ConflictError("policy predecessor is not the current local policy")
            db.execute(
                "INSERT INTO policies(event_id,project,version,created_at,event_json,policy_json) "
                "VALUES(?,?,?,?,?,?)",
                (
                    event.id,
                    project,
                    policy.version,
                    event.created_at,
                    event.model_dump_json(),
                    policy.model_dump_json(),
                ),
            )

    def latest_policy(self, project: str) -> tuple[NostrEvent, PolicyDocument]:
        with self.connect() as db:
            row = db.execute(
                "SELECT event_json,policy_json FROM policies WHERE project=? ORDER BY version DESC LIMIT 1",
                (project,),
            ).fetchone()
        if row is None:
            raise NotFoundError(f"no trusted policy for project: {project}")
        return NostrEvent.model_validate_json(row["event_json"]), PolicyDocument.model_validate_json(
            row["policy_json"]
        )

    def enqueue(
        self,
        project: str,
        track: str,
        branch: str,
        commit: str,
        idempotency_key: str,
        sha256: str,
        size: int,
        candidate_path: Path,
        submitter_pubkey: str | None = None,
        ci_grant: str | None = None,
    ) -> Job:
        now = unix_now()
        with self.transaction() as db:
            grant = None
            if ci_grant is not None:
                grant = ci_grants.check(
                    db,
                    ci_grant,
                    BuildRequest(
                        project=project,
                        track=track,
                        branch=branch,
                        commit=commit,
                        idempotency_key=idempotency_key,
                    ),
                    sha256,
                )
            existing = db.execute(
                "SELECT * FROM jobs WHERE project=? AND idempotency_key=?",
                (project, idempotency_key),
            ).fetchone()
            if existing is not None:
                # The documented idempotency key names the logical source
                # build, not one byte-for-byte local assembly. Android APKs
                # built for the same commit can differ across trusted build
                # environments. The first admitted candidate owns the job;
                # later callers follow that job through verification instead
                # of creating a competing publication.
                if (
                    existing["track"] != track
                    or existing["branch"] != branch
                    or existing["commit_hash"] != commit
                ):
                    raise ConflictError("idempotency key was already used for different content")
                if grant is not None and (
                    existing["candidate_sha256"] != sha256 or grant["job_id"] != existing["id"]
                ):
                    raise ConflictError("CI grant cannot adopt an existing unrelated job")
                return _job(existing)
            if grant is not None and grant["job_id"] is not None:
                raise ConflictError("CI grant was already consumed")
            db.execute(
                "INSERT INTO blobs(sha256,size,job_refs,unreferenced_at) VALUES(?,?,1,NULL) "
                "ON CONFLICT(sha256) DO UPDATE SET job_refs=job_refs+1,unreferenced_at=NULL",
                (sha256, size),
            )
            job_id = uuid.uuid4().hex
            db.execute(
                "INSERT INTO jobs(id,project,track,branch,commit_hash,idempotency_key,candidate_sha256,"
                "candidate_path,size,status,created_at,updated_at,submitter_pubkey) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    job_id,
                    project,
                    track,
                    branch,
                    commit,
                    idempotency_key,
                    sha256,
                    str(candidate_path),
                    size,
                    JobStatus.QUEUED,
                    now,
                    now,
                    submitter_pubkey,
                ),
            )
            if grant is not None:
                db.execute("UPDATE ci_grants SET job_id=? WHERE token_hash=?", (job_id, grant["token_hash"]))
            row = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            assert row is not None
            return _job(row)

    def job(self, job_id: str) -> Job:
        with self.connect() as db:
            row = db.execute(
                "SELECT jobs.*,CASE WHEN jobs.status=? AND NOT EXISTS ("
                "SELECT 1 FROM receipt_outbox JOIN releases "
                "ON releases.receipt_event_id=receipt_outbox.event_id "
                "WHERE releases.project=jobs.project AND releases.track=jobs.track "
                "AND releases.apk_sha256=jobs.release_sha256 "
                "AND receipt_outbox.delivered_at IS NULL) THEN 1 ELSE 0 END "
                "AS receipt_delivered FROM jobs WHERE jobs.id=?",
                (JobStatus.PUBLISHED, job_id),
            ).fetchone()
        if row is None:
            raise NotFoundError("job not found")
        return _job(row)

    def staging_references(self) -> tuple[set[str], set[str]]:
        """Return hashes needed locally and non-terminal job IDs."""
        with self.connect() as db:
            active_jobs = db.execute(
                "SELECT id,candidate_sha256 FROM jobs WHERE status IN (?,?)",
                (JobStatus.QUEUED, JobStatus.LEASED),
            ).fetchall()
            retained_blobs = db.execute(
                "SELECT sha256 FROM blobs WHERE job_refs>0 OR release_refs>0"
            ).fetchall()
        return (
            {str(row["sha256"]) for row in retained_blobs},
            {str(row["id"]) for row in active_jobs},
        )

    def lease(self, owner: str, seconds: int = 300, allow_manual: bool = False) -> Job | None:
        now = unix_now()
        with self.transaction() as db:
            row = db.execute(
                "SELECT jobs.* FROM jobs LEFT JOIN tracks ON tracks.project=jobs.project "
                "AND tracks.slug=jobs.track WHERE (tracks.slug IS NULL OR tracks.manual_only=0 OR ?) "
                "AND (status=? OR (status=? AND lease_until<?)) ORDER BY created_at LIMIT 1",
                (int(allow_manual), JobStatus.QUEUED, JobStatus.LEASED, now),
            ).fetchone()
            if row is None:
                return None
            db.execute(
                "UPDATE jobs SET status=?,lease_owner=?,lease_until=?,updated_at=? WHERE id=?",
                (JobStatus.LEASED, owner, now + seconds, now, row["id"]),
            )
            updated = db.execute("SELECT * FROM jobs WHERE id=?", (row["id"],)).fetchone()
            assert updated is not None
            return _job(updated)

    def lease_job(
        self,
        job_id: str,
        owner: str,
        seconds: int = 300,
        allow_manual: bool = False,
    ) -> Job | None:
        """Lease exactly one named job without consuming another queue entry."""
        now = unix_now()
        with self.transaction() as db:
            row = db.execute(
                "SELECT jobs.* FROM jobs LEFT JOIN tracks ON tracks.project=jobs.project "
                "AND tracks.slug=jobs.track WHERE jobs.id=? "
                "AND (tracks.slug IS NULL OR tracks.manual_only=0 OR ?) "
                "AND (status=? OR (status=? AND lease_until<?))",
                (job_id, int(allow_manual), JobStatus.QUEUED, JobStatus.LEASED, now),
            ).fetchone()
            if row is None:
                return None
            db.execute(
                "UPDATE jobs SET status=?,lease_owner=?,lease_until=?,updated_at=? WHERE id=?",
                (JobStatus.LEASED, owner, now + seconds, now, job_id),
            )
            updated = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            assert updated is not None
            return _job(updated)

    def renew_lease(self, job_id: str, owner: str, seconds: int = 300) -> bool:
        """Extend a live lease only while it is still owned by ``owner``."""
        now = unix_now()
        with self.transaction() as db:
            updated = db.execute(
                "UPDATE jobs SET lease_until=?,updated_at=? WHERE id=? AND status=? "
                "AND lease_owner=? AND lease_until>=?",
                (now + seconds, now, job_id, JobStatus.LEASED, owner, now),
            )
            return updated.rowcount == 1

    def fail_job(self, job_id: str, error: str, lease_owner: str | None = None) -> bool:
        now = unix_now()
        with self.transaction() as db:
            row = db.execute(
                "SELECT candidate_sha256,status,lease_owner FROM jobs WHERE id=?", (job_id,)
            ).fetchone()
            if row is None:
                raise NotFoundError("job not found")
            if row["status"] in {JobStatus.PUBLISHED, JobStatus.FAILED}:
                return False
            if lease_owner is not None and (
                row["status"] != JobStatus.LEASED or row["lease_owner"] != lease_owner
            ):
                return False
            db.execute(
                "UPDATE jobs SET status=?,error=?,updated_at=?,lease_owner=NULL,lease_until=NULL WHERE id=?",
                (JobStatus.FAILED, error[:2000], now, job_id),
            )
            self._release_job_ref(db, row["candidate_sha256"], now)
            return True

    def commit_release(
        self,
        job_id: str,
        apk_hash: str,
        apk_size: int,
        metadata_hash: str,
        version_name: str,
        version_code: int,
        package_name: str,
        certificate_sha256: str,
        maintainer_npub: str,
        installable_alongside_stable: bool,
        policy_event_id: str,
        published_at: int,
        receipt_event: NostrEvent,
        blossom_servers: list[str],
        lease_owner: str | None = None,
        provision_role: str | None = None,
        provision_signer_profile: str | None = None,
    ) -> None:
        now = unix_now()
        with self.transaction() as db:
            job = db.execute("SELECT * FROM jobs WHERE id=?", (job_id,)).fetchone()
            if job is None:
                raise NotFoundError("job not found")
            if job["status"] == JobStatus.PUBLISHED:
                return
            if job["status"] != JobStatus.LEASED:
                raise ConflictError("job must be leased before publishing")
            if lease_owner is not None and job["lease_owner"] != lease_owner:
                raise ConflictError("job lease is owned by another worker")
            previous = db.execute(
                "SELECT * FROM releases WHERE project=? AND track=? "
                "ORDER BY version_code DESC,id DESC LIMIT 1",
                (job["project"], job["track"]),
            ).fetchone()
            if previous is not None and version_code <= int(previous["version_code"]):
                same_release_without_receipt = (
                    version_code == int(previous["version_code"])
                    and apk_hash == previous["apk_sha256"]
                    and previous["receipt_event_id"] is None
                )
                if version_code == int(previous["version_code"]) and apk_hash != previous["apk_sha256"]:
                    raise ConflictError("same versionCode was already published with another APK hash")
                if not same_release_without_receipt:
                    raise ConflictError("release versionCode must increase monotonically")
            reservation = None
            if installable_alongside_stable and job["submitter_pubkey"] is not None:
                reservation = db.execute(
                    "SELECT * FROM version_reservations WHERE project=? AND track=? AND commit_hash=?",
                    (job["project"], job["track"], job["commit_hash"]),
                ).fetchone()
                if reservation is not None:
                    if reservation["branch"] != job["branch"]:
                        raise ConflictError("version reservation source branch changed")
                    if int(reservation["version_code"]) != version_code:
                        raise ConflictError("APK versionCode does not match its reservation")
            track = db.execute(
                "SELECT role,package_name,source_branch FROM tracks WHERE project=? AND slug=?",
                (job["project"], job["track"]),
            ).fetchone()
            if track is None:
                if provision_role != "development":
                    raise ConflictError("unknown tracks require an authorized development provision")
                db.execute(
                    "INSERT INTO tracks(project,slug,role,manual_only,signer_profile,package_name,"
                    "source_branch) VALUES(?,?,?,0,?,?,?)",
                    (
                        job["project"],
                        job["track"],
                        provision_role,
                        provision_signer_profile,
                        package_name,
                        job["branch"],
                    ),
                )
            elif track["package_name"] != package_name or track["source_branch"] != job["branch"]:
                raise ConflictError("track package or source-branch binding changed during publication")
            self._ensure_blob(db, apk_hash, apk_size, uploaded=True)
            db.execute(
                "UPDATE blobs SET release_refs=release_refs+1,unreferenced_at=NULL WHERE sha256=?",
                (apk_hash,),
            )
            db.execute(
                "INSERT INTO releases(project,track,version_name,version_code,branch,commit_hash,created_at,"
                "apk_sha256,metadata_sha256,package_name,certificate_sha256,maintainer_npub,"
                "installable_alongside_stable,policy_event_id,published_at,receipt_event_id,"
                "receipt_event_json,blossom_servers_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (
                    job["project"],
                    job["track"],
                    version_name,
                    version_code,
                    job["branch"],
                    job["commit_hash"],
                    job["created_at"],
                    apk_hash,
                    metadata_hash,
                    package_name,
                    certificate_sha256,
                    maintainer_npub,
                    int(installable_alongside_stable),
                    policy_event_id,
                    published_at,
                    receipt_event.id,
                    receipt_event.model_dump_json(),
                    json.dumps(blossom_servers, separators=(",", ":")),
                ),
            )
            db.execute(
                "INSERT INTO receipt_outbox(event_id,event_json,created_at) VALUES(?,?,?)",
                (receipt_event.id, receipt_event.model_dump_json(), now),
            )
            db.execute(
                "UPDATE jobs SET status=?,release_sha256=?,updated_at=?,lease_owner=NULL,"
                "lease_until=NULL WHERE id=?",
                (JobStatus.PUBLISHED, apk_hash, now, job_id),
            )
            if reservation is not None:
                db.execute(
                    "UPDATE version_reservations SET claimed_at=? "
                    "WHERE project=? AND track=? AND commit_hash=?",
                    (now, job["project"], job["track"], job["commit_hash"]),
                )
            self._release_job_ref(db, job["candidate_sha256"], now)

    def assert_release_progress(self, project: str, track: str, version_code: int, apk_hash: str) -> None:
        with self.connect() as db:
            previous = db.execute(
                "SELECT version_code,apk_sha256,receipt_event_id FROM releases "
                "WHERE project=? AND track=? "
                "ORDER BY version_code DESC,id DESC LIMIT 1",
                (project, track),
            ).fetchone()
        if previous is None:
            return
        if (
            version_code == int(previous["version_code"])
            and apk_hash == previous["apk_sha256"]
            and previous["receipt_event_id"] is None
        ):
            return
        if version_code == int(previous["version_code"]) and apk_hash != previous["apk_sha256"]:
            raise ConflictError("same versionCode was already published with another APK hash")
        if version_code <= int(previous["version_code"]):
            raise ConflictError("release versionCode must increase monotonically")

    @staticmethod
    def _ensure_blob(db: sqlite3.Connection, sha256: str, size: int, uploaded: bool) -> None:
        db.execute(
            "INSERT INTO blobs(sha256,size,uploaded) VALUES(?,?,?) "
            "ON CONFLICT(sha256) DO UPDATE SET uploaded=MAX(uploaded,excluded.uploaded)",
            (sha256, size, int(uploaded)),
        )

    @staticmethod
    def _set_path(
        db: sqlite3.Connection,
        path: str,
        sha256: str,
        project: str,
        track: str,
        content_type: str,
        now: int,
    ) -> None:
        old = db.execute("SELECT sha256 FROM manifest_paths WHERE path=?", (path,)).fetchone()
        if old is not None and old["sha256"] == sha256:
            db.execute("UPDATE manifest_paths SET updated_at=? WHERE path=?", (now, path))
            return
        if old is not None:
            db.execute(
                "UPDATE blobs SET manifest_refs=manifest_refs-1, "
                "unreferenced_at=CASE WHEN manifest_refs=1 AND job_refs=0 AND release_refs=0 "
                "THEN ? ELSE unreferenced_at END "
                "WHERE sha256=?",
                (now, old["sha256"]),
            )
        db.execute(
            "INSERT INTO manifest_paths(path,sha256,project,track,content_type,updated_at) "
            "VALUES(?,?,?,?,?,?) ON CONFLICT(path) DO UPDATE SET sha256=excluded.sha256,"
            "project=excluded.project,track=excluded.track,content_type=excluded.content_type,"
            "updated_at=excluded.updated_at",
            (path, sha256, project, track, content_type, now),
        )
        db.execute(
            "UPDATE blobs SET manifest_refs=manifest_refs+1,unreferenced_at=NULL WHERE sha256=?",
            (sha256,),
        )

    @staticmethod
    def _release_job_ref(db: sqlite3.Connection, sha256: str, now: int) -> None:
        db.execute(
            "UPDATE blobs SET job_refs=job_refs-1, unreferenced_at=CASE "
            "WHEN job_refs=1 AND manifest_refs=0 AND release_refs=0 "
            "THEN ? ELSE unreferenced_at END WHERE sha256=?",
            (now, sha256),
        )

    def paths(self) -> list[ManifestPath]:
        with self.connect() as db:
            rows = db.execute("SELECT path,sha256 FROM manifest_paths ORDER BY path").fetchall()
        return [ManifestPath(path=row["path"], sha256=row["sha256"]) for row in rows]

    def replace_site_paths(self, assets: list[tuple[str, str, int, str]]) -> bool:
        """Replace the immutable site and remove legacy manifest-backed release paths."""
        now = unix_now()
        desired = {path: (sha256, size, content_type) for path, sha256, size, content_type in assets}
        with self.transaction() as db:
            existing_rows = db.execute(
                "SELECT path,sha256 FROM manifest_paths WHERE track='__site__'"
            ).fetchall()
            existing = {str(row["path"]): str(row["sha256"]) for row in existing_rows}
            release_rows = db.execute("SELECT path FROM manifest_paths WHERE track!='__site__'").fetchall()
            collisions = [row for row in release_rows if str(row["path"]) in desired]
            if collisions:
                names = ", ".join(str(row["path"]) for row in collisions)
                raise ConflictError(f"site assets collide with release paths: {names}")

            changed = existing != {path: value[0] for path, value in desired.items()} or bool(release_rows)
            if not changed:
                return False

            for path, old_hash in existing.items():
                if path not in desired:
                    db.execute("DELETE FROM manifest_paths WHERE path=?", (path,))
                    db.execute(
                        "UPDATE blobs SET manifest_refs=manifest_refs-1, "
                        "unreferenced_at=CASE WHEN manifest_refs=1 AND job_refs=0 AND release_refs=0 "
                        "THEN ? ELSE unreferenced_at END WHERE sha256=?",
                        (now, old_hash),
                    )

            for row in release_rows:
                old = db.execute("SELECT sha256 FROM manifest_paths WHERE path=?", (row["path"],)).fetchone()
                db.execute("DELETE FROM manifest_paths WHERE path=?", (row["path"],))
                if old is not None:
                    db.execute(
                        "UPDATE blobs SET manifest_refs=manifest_refs-1, "
                        "unreferenced_at=CASE WHEN manifest_refs=1 AND job_refs=0 AND release_refs=0 "
                        "THEN ? ELSE unreferenced_at END WHERE sha256=?",
                        (now, old["sha256"]),
                    )

            for path, (sha256, size, content_type) in desired.items():
                self._ensure_blob(db, sha256, size, uploaded=True)
                self._set_path(db, path, sha256, "__site__", "__site__", content_type, now)

            path_rows = db.execute("SELECT path,sha256 FROM manifest_paths").fetchall()
            lines = sorted(f"{row['sha256']} {row['path']}\n" for row in path_rows)
            current_aggregate = hashlib.sha256("".join(lines).encode()).hexdigest()
            db.execute(
                "INSERT INTO outbox(aggregate_hash,created_at) VALUES(?,?)",
                (current_aggregate, now),
            )
            return True

    def pending_outbox(self) -> list[sqlite3.Row]:
        with self.connect() as db:
            return list(db.execute("SELECT * FROM outbox WHERE delivered_at IS NULL ORDER BY id"))

    def deliver_outbox_through(self, outbox_id: int) -> None:
        with self.transaction() as db:
            db.execute("UPDATE outbox SET delivered_at=? WHERE id<=?", (unix_now(), outbox_id))

    def pending_receipts(self) -> list[NostrEvent]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT event_json FROM receipt_outbox WHERE delivered_at IS NULL ORDER BY created_at"
            ).fetchall()
        return [NostrEvent.model_validate_json(row["event_json"]) for row in rows]

    def deliver_receipt(self, event_id: str) -> None:
        with self.transaction() as db:
            db.execute(
                "UPDATE receipt_outbox SET delivered_at=? WHERE event_id=?",
                (unix_now(), event_id),
            )

    def gc_candidates(self, grace_seconds: int, now: int | None = None) -> list[tuple[str, int]]:
        cutoff = (now or unix_now()) - grace_seconds
        with self.connect() as db:
            rows = db.execute(
                "SELECT sha256,size FROM blobs WHERE uploaded=1 AND manifest_refs=0 AND job_refs=0 "
                "AND release_refs=0 "
                "AND unreferenced_at IS NOT NULL AND unreferenced_at<=?",
                (cutoff,),
            ).fetchall()
        return [(row["sha256"], row["size"]) for row in rows]

    def mark_blob_deleted(self, sha256: str) -> bool:
        with self.transaction() as db:
            cursor = db.execute(
                "UPDATE blobs SET uploaded=0,unreferenced_at=NULL "
                "WHERE sha256=? AND uploaded=1 AND manifest_refs=0 AND job_refs=0 AND release_refs=0",
                (sha256,),
            )
            return cursor.rowcount == 1

    def collect_blob(
        self,
        sha256: str,
        grace_seconds: int,
        now: int,
        delete: Callable[[str], None],
    ) -> bool:
        """Recheck refs and hold the single-node write lock across remote DELETE."""
        cutoff = now - grace_seconds
        with self.transaction() as db:
            row = db.execute(
                "SELECT 1 FROM blobs WHERE sha256=? AND uploaded=1 AND manifest_refs=0 "
                "AND job_refs=0 AND release_refs=0 AND unreferenced_at IS NOT NULL "
                "AND unreferenced_at<=?",
                (sha256, cutoff),
            ).fetchone()
            if row is None:
                return False
            delete(sha256)
            db.execute(
                "UPDATE blobs SET uploaded=0,unreferenced_at=NULL WHERE sha256=?",
                (sha256,),
            )
            return True

    def dashboard(self) -> list[dict[str, Any]]:
        with self.connect() as db:
            rows = db.execute(
                "SELECT r.* FROM releases r JOIN (SELECT project,track,MAX(id) id FROM releases "
                "GROUP BY project,track) latest ON r.id=latest.id ORDER BY r.project,r.track"
            ).fetchall()
        return [dict(row) for row in rows]

    def release_history(self) -> list[dict[str, Any]]:
        """All published releases, newest first within each project/track."""
        with self.connect() as db:
            rows = db.execute(
                "SELECT * FROM releases ORDER BY project,track,version_code DESC,id DESC"
            ).fetchall()
        return [dict(row) for row in rows]

    def enqueue_receipt(self, event: NostrEvent) -> None:
        """Idempotently queue an additional immutable receipt for relay delivery."""
        with self.transaction() as db:
            db.execute(
                "INSERT OR IGNORE INTO receipt_outbox(event_id,event_json,created_at) VALUES(?,?,?)",
                (event.id, event.model_dump_json(), unix_now()),
            )

    def blob_row(self, sha256: str) -> sqlite3.Row | None:
        with self.connect() as db:
            return cast(
                sqlite3.Row | None,
                db.execute("SELECT * FROM blobs WHERE sha256=?", (sha256,)).fetchone(),
            )

    def published_blob(self, sha256: str) -> sqlite3.Row | None:
        with self.connect() as db:
            return cast(
                sqlite3.Row | None,
                db.execute(
                    "SELECT blobs.* FROM blobs WHERE blobs.sha256=? AND EXISTS ("
                    "SELECT 1 FROM releases WHERE releases.apk_sha256=blobs.sha256)",
                    (sha256,),
                ).fetchone(),
            )


def _token_digest(secret: str, salt: bytes) -> bytes:
    return hashlib.scrypt(secret.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)


def _job(row: sqlite3.Row) -> Job:
    try:
        receipt_delivered = bool(row["receipt_delivered"])
    except IndexError:
        receipt_delivered = False
    return Job(
        id=row["id"],
        project=row["project"],
        track=row["track"],
        branch=row["branch"],
        commit=row["commit_hash"],
        candidate_sha256=row["candidate_sha256"],
        size=row["size"],
        status=JobStatus(row["status"]),
        created_at=row["created_at"],
        updated_at=row["updated_at"],
        error=row["error"],
        release_sha256=row["release_sha256"],
        submitter_pubkey=row["submitter_pubkey"],
        receipt_delivered=receipt_delivered,
    )


def _version_reservation(row: sqlite3.Row) -> VersionReservation:
    return VersionReservation(
        project=row["project"],
        track=row["track"],
        branch=row["branch"],
        commit=row["commit_hash"],
        version_code=row["version_code"],
        idempotency_key=row["idempotency_key"],
        created_at=row["created_at"],
        claimed_at=row["claimed_at"],
    )


class ReadOnlyRegistry(Registry):
    """Private signers can observe admitted jobs but never mutate intake authority."""

    def __init__(self, database: Path) -> None:
        self.database = database.resolve(strict=True)
        self._write_lock = threading.RLock()

    def connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(
            self.database.as_uri() + "?mode=ro", uri=True, timeout=30, isolation_level=None
        )
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA query_only=ON")
        return connection
