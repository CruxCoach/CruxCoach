import json
import time
from pathlib import Path
from typing import Literal
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict

from .canonical import canonical_json
from .models import CertificateRule, PolicyDocument
from .nostr import decode_npub
from .project_config import (
    AndroidScopeConfig,
    AndroidSection,
    APKTrackSection,
    ProjectConfig,
    ProjectSection,
    ServicesSection,
)


class SetupAnswers(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    name: str
    slug: str
    description: str
    icon: str = ""
    root_pubkey: str
    validator_pubkey: str
    production_package: str
    production_certificate_sha256: str
    production_track: str = "stable"
    development_package: str
    development_certificate_sha256: str
    development_track: str = "dev"
    development_track_pattern: str = "feat-*"
    blossom: tuple[str, ...]
    event_servers: tuple[str, ...]
    nsite_gateway: str
    intake_url: str
    build_command: str
    artifact_glob: str
    profile: Literal["local", "self-hosted", "existing"] = "existing"
    upload_token_env: str = "APKTRACK_UPLOAD_TOKEN"


def validated_config(answers: SetupAnswers) -> ProjectConfig:
    return ProjectConfig(
        schema_version=2,
        protocol="org.apktrack.project",
        project=ProjectSection.model_validate(
            {
                "name": answers.name,
                "slug": answers.slug,
                "description": answers.description,
                "icon": answers.icon,
                "root_pubkey": decode_npub(answers.root_pubkey),
            }
        ),
        services=ServicesSection.model_validate(
            {
                "profile": answers.profile,
                "blossom": answers.blossom,
                "event_servers": answers.event_servers,
                "nsite_gateway": answers.nsite_gateway,
                "validator_pubkey": decode_npub(answers.validator_pubkey),
            }
        ),
        apktrack=APKTrackSection.model_validate(
            {
                "url": answers.intake_url,
                "upload_token_env": answers.upload_token_env,
                "build_command": answers.build_command,
                "artifact_glob": answers.artifact_glob,
            }
        ),
        android=AndroidSection(
            scope=(
                AndroidScopeConfig(
                    role="production",
                    package=answers.production_package,
                    certificate_sha256=_fingerprint(answers.production_certificate_sha256),
                    tracks=(answers.production_track,),
                ),
                AndroidScopeConfig(
                    role="development",
                    package=answers.development_package,
                    certificate_sha256=_fingerprint(answers.development_certificate_sha256),
                    tracks=(answers.development_track,),
                    track_patterns=(answers.development_track_pattern,)
                    if answers.development_track_pattern
                    else (),
                ),
            )
        ),
    )


def render_project_toml(config: ProjectConfig) -> str:
    quote = json.dumps
    lines = [
        "schema_version = 2",
        'protocol = "org.apktrack.project"',
        "",
        "[project]",
        f"name = {quote(config.project.name)}",
        f"slug = {quote(config.project.slug)}",
        f"description = {quote(config.project.description)}",
        f"root_pubkey = {quote(config.project.root_pubkey)}",
        f"icon = {quote(str(config.project.icon))}",
        "",
        "[services]",
        f"profile = {quote(config.services.profile)}",
        f"blossom = [{', '.join(quote(str(value)) for value in config.services.blossom)}]",
        f"event_servers = [{', '.join(quote(str(value)) for value in config.services.event_servers)}]",
        f"nsite_gateway = {quote(str(config.services.nsite_gateway))}",
        f"validator_pubkey = {quote(config.services.validator_pubkey)}",
        "",
        "[apktrack]",
        f"url = {quote(str(config.apktrack.url))}",
        f"nsec_env = {quote(config.apktrack.nsec_env)}",
        f"upload_token_env = {quote(config.apktrack.upload_token_env)}",
        f"build_command = {quote(config.apktrack.build_command)}",
        f"artifact_glob = {quote(config.apktrack.artifact_glob)}",
    ]
    for scope in config.android.scope:
        lines.extend(
            [
                "",
                "[[android.scope]]",
                f"role = {quote(scope.role)}",
                f"package = {quote(scope.package)}",
                f"package_patterns = [{', '.join(quote(value) for value in scope.package_patterns)}]",
                f"certificate_sha256 = {quote(scope.certificate_sha256)}",
                f"tracks = [{', '.join(quote(value) for value in scope.tracks)}]",
                f"track_patterns = [{', '.join(quote(value) for value in scope.track_patterns)}]",
            ]
        )
    return "\n".join(lines) + "\n"


def setup_artifacts(answers: SetupAnswers, issued_at: int | None = None) -> dict[str, str]:
    config = validated_config(answers)
    timestamp = issued_at if issued_at is not None else int(time.time())
    policy = PolicyDocument(
        schema_version=2,
        project=config.project.slug,
        version=1,
        previous_event_id=None,
        issued_at=timestamp,
        valid_from=None,
        valid_until=None,
        certificates=tuple(
            CertificateRule(
                package_name=scope.package,
                package_patterns=scope.package_patterns,
                certificate_sha256=scope.certificate_sha256,
                roles=(scope.role,),
                tracks=scope.tracks,
                track_patterns=scope.track_patterns,
                valid_from=None,
                valid_until=None,
            )
            for scope in config.android.scope
        ),
    )
    policy_event = {
        "pubkey": config.project.root_pubkey,
        "created_at": timestamp,
        "kind": 30078,
        "tags": [["d", f"apktrack-policy:{config.project.slug}"]],
        "content": canonical_json(policy.model_dump(mode="json")).decode().rstrip("\n"),
    }
    descriptor = {
        "protocol": "org.apktrack.project-directory",
        "schema_version": 1,
        "revision": 1,
        "identifier": config.project.slug,
        "name": config.project.name,
        "description": config.project.description,
        "root_pubkey": config.project.root_pubkey,
        "nsite": _project_url(str(config.services.nsite_gateway), config.project.slug),
        "icon": str(config.project.icon),
        "tags": [],
        "packages": [scope.package for scope in config.android.scope],
        "tracks": [
            {"slug": track, "role": scope.role, "package_name": scope.package}
            for scope in config.android.scope
            for track in scope.tracks
        ],
        "event_servers": [str(value) for value in config.services.event_servers],
        "validator_pubkeys": [config.services.validator_pubkey],
        "dynamic_tracks": [
            {"pattern": pattern, "role": scope.role, "package_name": scope.package}
            for scope in config.android.scope
            for pattern in scope.track_patterns
        ],
        "status": "listed",
        "previous_event_id": None,
        "updated_at": timestamp,
    }
    descriptor_event = {
        "pubkey": config.project.root_pubkey,
        "created_at": timestamp,
        "kind": 30380,
        "tags": [["d", config.project.slug], ["t", "apktrack-project"]],
        "content": canonical_json(descriptor).decode().rstrip("\n"),
    }
    agents = _agents_section(config)
    summary = {
        "protocol": "org.apktrack.terminal-setup",
        "schema_version": 1,
        "project": config.project.slug,
        "project_nsite_url": descriptor["nsite"],
        "files": {
            "config": ".apktrack/project.toml",
            "policy_sign_request": ".apktrack/policy.unsigned.json",
            "descriptor_sign_request": ".apktrack/project-descriptor.unsigned.json",
            "agents_section": ".apktrack/AGENTS.apktrack.md",
        },
        "next_steps": [
            "Root-sign policy.unsigned.json without changing any field.",
            "Save the verified result as .apktrack/policy.signed.json.",
            "Run apktrack bootstrap with --dry-run before the write-enabled command.",
            "Create only a development-scoped admission token on the private control plane.",
            "Root-sign and publish the descriptor as an explicit owner action.",
            "Publish one development APK and require published plus receipt_delivered=true.",
            f"Open {descriptor['nsite']} and verify the build and APK download.",
        ],
    }
    return {
        "project.toml": render_project_toml(config),
        "policy.unsigned.json": canonical_json(policy_event).decode(),
        "project-descriptor.unsigned.json": canonical_json(descriptor_event).decode(),
        "AGENTS.apktrack.md": agents,
        "setup-summary.json": canonical_json(summary).decode(),
    }


def write_setup_artifacts(
    answers: SetupAnswers,
    output_directory: Path,
    *,
    force: bool = False,
    issued_at: int | None = None,
) -> tuple[Path, ...]:
    artifacts = setup_artifacts(answers, issued_at)
    targets = tuple(output_directory / name for name in artifacts)
    existing = [path for path in targets if path.exists()]
    if existing and not force:
        raise FileExistsError("refusing to overwrite: " + ", ".join(str(path) for path in existing))
    output_directory.mkdir(parents=True, exist_ok=True)
    for name, content in artifacts.items():
        (output_directory / name).write_text(content, encoding="utf-8")
    return targets


def _fingerprint(value: str) -> str:
    return value.replace(":", "").lower()


def _project_url(gateway: str, project: str) -> str:
    parts = urlsplit(gateway)
    query = dict(parse_qsl(parts.query, keep_blank_values=True))
    query["project"] = project
    return urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), ""))


def _agents_section(config: ProjectConfig) -> str:
    tracks = ", ".join(
        f"{track} ({scope.role})"
        for scope in config.android.scope
        for track in scope.tracks
    )
    return (
        "## APKTrack publishing\n\n"
        f"- Configuration: `.apktrack/project.toml`; project `{config.project.slug}`; tracks: {tracks}.\n"
        "- Publish APKs only with `apktrack publish-build`; never upload directly to Blossom "
        "or construct receipts/manifests.\n"
        "- Inspect package, certificate, branch/worktree, commit, and exactly one artifact "
        "before publishing.\n"
        "- Production tracks are manual-only and require explicit authorization for the exact "
        "release. Never derive `stable` from a branch.\n"
        f"- The scoped upload value lives only in the secret provider named "
        f"`{config.apktrack.upload_token_env}`; never print or commit it.\n"
        "- Success requires `status=published` and `receipt_delivered=true`; queued or leased "
        "is not success.\n"
        "- Preserve the deterministic idempotency key "
        "`<project>-<track>-<lowercase-commit>` when diagnosing retries.\n"
    )
