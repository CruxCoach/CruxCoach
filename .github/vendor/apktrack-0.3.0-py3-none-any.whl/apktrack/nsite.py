from .canonical import sha256_bytes
from .models import ManifestPath, NostrEvent

ROOT_MANIFEST_KIND = 15128
NAMED_MANIFEST_KIND = 35128
SNAPSHOT_KIND = 5128


def aggregate_hash(paths: list[ManifestPath]) -> str:
    lines = sorted(f"{entry.sha256} {entry.path}\n" for entry in paths)
    return sha256_bytes("".join(lines).encode())


def manifest_tags(
    paths: list[ManifestPath], servers: list[str], site_name: str | None = None
) -> list[list[str]]:
    if not paths:
        raise ValueError("manifest requires at least one path")
    if len({entry.path for entry in paths}) != len(paths):
        raise ValueError("duplicate manifest path")
    tags: list[list[str]] = []
    if site_name is not None:
        if (
            not 1 <= len(site_name) <= 13
            or site_name.endswith("-")
            or any(character not in "abcdefghijklmnopqrstuvwxyz0123456789-" for character in site_name)
        ):
            raise ValueError("NIP-5A named-site d tag must be a 1-13 character DNS label")
        tags.append(["d", site_name])
    tags.extend(["path", entry.path, entry.sha256] for entry in sorted(paths, key=lambda x: x.path))
    tags.append(["x", aggregate_hash(paths), "aggregate"])
    tags.extend(["server", server.rstrip("/")] for server in servers)
    return tags


def snapshot_tags(manifest: NostrEvent) -> list[list[str]]:
    if manifest.kind == ROOT_MANIFEST_KIND:
        address = f"{ROOT_MANIFEST_KIND}:{manifest.pubkey}:"
    elif manifest.kind == NAMED_MANIFEST_KIND:
        d_values = [tag[1] for tag in manifest.tags if len(tag) == 2 and tag[0] == "d"]
        if len(d_values) != 1:
            raise ValueError("named manifest requires exactly one d tag")
        address = f"{NAMED_MANIFEST_KIND}:{manifest.pubkey}:{d_values[0]}"
    else:
        raise ValueError("snapshot parent must be an nsite manifest")
    copied = [list(tag) for tag in manifest.tags if tag and tag[0] in {"path", "x", "server"}]
    return [["a", address], *copied]
