import json
import secrets
import sys
import time
from pathlib import Path
from typing import Annotated

import httpx
import typer

from .apk import AndroidSdkApkInspector
from .canonical import sha256_file
from .config import Settings
from .errors import AdapterError, APKTrackError
from .http_auth import nip98_header
from .models import BuildRequest, Job, JobStatus, NostrEvent, VersionReservation
from .policy import parse_and_verify_policy_event
from .project_config import bootstrap_project, load_project_config, validate_initial_policy
from .runtime import build_service
from .setup_project import SetupAnswers, write_setup_artifacts
from .storage import Registry
from .verification import select_latest_policy, verify_release

app = typer.Typer(
    no_args_is_help=True,
    pretty_exceptions_show_locals=False,
    help="Publish and independently verify policy-bound APKs.",
)
DEFAULT_DATABASE = Settings().database
DEFAULT_SERVER_URL = "http://127.0.0.1:18080"


@app.command("setup-project")
def setup_project_command(
    project: Annotated[str | None, typer.Option(help="Lowercase project slug")] = None,
    name: Annotated[str | None, typer.Option(help="Public project name")] = None,
    description: Annotated[str | None, typer.Option(help="Public project description")] = None,
    root: Annotated[str | None, typer.Option(help="Root npub or public hex key")] = None,
    validator: Annotated[str | None, typer.Option(help="Receipt-validator npub or public hex key")] = None,
    production_package: Annotated[str | None, typer.Option()] = None,
    production_certificate: Annotated[str | None, typer.Option(help="Production certificate SHA-256")] = None,
    production_track: Annotated[str, typer.Option()] = "stable",
    development_package: Annotated[str | None, typer.Option()] = None,
    development_certificate: Annotated[
        str | None, typer.Option(help="Development certificate SHA-256")
    ] = None,
    development_track: Annotated[str, typer.Option()] = "dev",
    development_track_pattern: Annotated[str, typer.Option()] = "feat-*",
    blossom: Annotated[list[str] | None, typer.Option(help="Repeat for each HTTPS Blossom server")] = None,
    event_server: Annotated[list[str] | None, typer.Option(help="Repeat for each WSS event server")] = None,
    gateway: Annotated[str | None, typer.Option(help="Public directory/nsite HTTPS URL")] = None,
    intake: Annotated[str | None, typer.Option(help="Public APKTrack intake HTTPS URL")] = None,
    build_command: Annotated[str | None, typer.Option()] = None,
    artifact_glob: Annotated[str | None, typer.Option()] = None,
    icon: Annotated[str, typer.Option(help="Optional public HTTPS icon URL")] = "",
    profile: Annotated[str, typer.Option(help="local, self-hosted, or existing")] = "existing",
    upload_token_env: Annotated[str, typer.Option()] = "APKTRACK_UPLOAD_TOKEN",
    output_directory: Annotated[Path, typer.Option()] = Path(".apktrack"),
    non_interactive: Annotated[
        bool, typer.Option(help="Fail instead of prompting for missing public values")
    ] = False,
    force: Annotated[bool, typer.Option(help="Explicitly replace existing generated setup files")] = False,
) -> None:
    """Generate the complete secret-free project setup without using the browser forms."""

    def required(value: str | None, label: str) -> str:
        if value is not None:
            return value
        if non_interactive:
            raise typer.BadParameter(f"--{label.lower().replace(' ', '-')} is required")
        return str(typer.prompt(label))

    def repeated(values: list[str] | None, label: str) -> tuple[str, ...]:
        if values:
            return tuple(values)
        if non_interactive:
            raise typer.BadParameter(f"at least one --{label.lower().replace(' ', '-')} is required")
        entered = typer.prompt(f"{label} (comma-separated)")
        return tuple(item.strip() for item in entered.split(",") if item.strip())

    answers = SetupAnswers.model_validate(
        {
            "name": required(name, "name"),
            "slug": required(project, "project"),
            "description": required(description, "description"),
            "icon": icon,
            "root_pubkey": required(root, "root"),
            "validator_pubkey": required(validator, "validator"),
            "production_package": required(production_package, "production package"),
            "production_certificate_sha256": required(production_certificate, "production certificate"),
            "production_track": production_track,
            "development_package": required(development_package, "development package"),
            "development_certificate_sha256": required(development_certificate, "development certificate"),
            "development_track": development_track,
            "development_track_pattern": development_track_pattern,
            "blossom": repeated(blossom, "blossom"),
            "event_servers": repeated(event_server, "event server"),
            "nsite_gateway": required(gateway, "gateway"),
            "intake_url": required(intake, "intake"),
            "build_command": required(build_command, "build command"),
            "artifact_glob": required(artifact_glob, "artifact glob"),
            "profile": profile,
            "upload_token_env": upload_token_env,
        }
    )
    try:
        paths = write_setup_artifacts(answers, output_directory, force=force)
    except (ValueError, FileExistsError, APKTrackError) as exc:
        raise typer.BadParameter(str(exc)) from exc
    for path in paths:
        typer.echo(f"wrote {path}")
    typer.echo("next: Root-sign policy.unsigned.json and save the verified event as policy.signed.json")
    typer.echo(
        f"then: apktrack bootstrap --config {output_directory / 'project.toml'} "
        f"--policy-event {output_directory / 'policy.signed.json'} --dry-run"
    )
    typer.echo("no key, token, service, deployment, or public event was created")


@app.command("bootstrap")
def bootstrap(
    config: Annotated[Path, typer.Option(exists=True, readable=True)] = Path(".apktrack/project.toml"),
    policy_event: Annotated[
        Path | None,
        typer.Option(
            exists=True,
            readable=True,
            help="Root-signed policy to validate and import in the same bootstrap",
        ),
    ] = None,
    dry_run: Annotated[
        bool, typer.Option(help="Validate and show local registry actions without writing")
    ] = False,
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    """Validate a secret-free project config and initialize only the local registry."""
    project = load_project_config(config)
    signed_policy: NostrEvent | None = None
    if policy_event is not None:
        signed_policy = NostrEvent.model_validate_json(policy_event.read_text())
        policy = parse_and_verify_policy_event(
            signed_policy,
            project.project.root_pubkey,
            project.project.slug,
        )
        validate_initial_policy(project, policy)
    actions = bootstrap_project(project, database, dry_run=dry_run)
    if signed_policy is not None:
        actions.append(f"trusted Root-signed policy {signed_policy.id}")
        if not dry_run:
            service = build_service(Settings(database=database, backend="local"))
            service.import_policy(project.project.slug, signed_policy.model_dump_json())
    typer.echo(f"validated project configuration schema {project.schema_version}")
    for action in actions:
        typer.echo(("would add " if dry_run else "added ") + action)
    if dry_run:
        typer.echo("dry-run: no registry, policy, key, service, or deployment was changed")


@app.command("add-project")
def add_project(
    project: Annotated[str, typer.Argument()],
    root: Annotated[str, typer.Option(help="Trusted project npub or hex pubkey")],
    validator: Annotated[
        str | None,
        typer.Option(help="Pinned release-receipt validator hex pubkey"),
    ] = None,
    default_role: Annotated[str, typer.Option()] = "development",
    development_signer_profile: Annotated[
        str | None, typer.Option(help="Default server-side signer profile for dynamic development tracks")
    ] = None,
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    registry = Registry(database)
    registry.add_project(project, root, default_role, validator, development_signer_profile)
    typer.echo(f"registered project {project}")


@app.command("set-development-signer")
def set_development_signer(
    project: Annotated[str, typer.Argument()],
    profile: Annotated[str, typer.Option(help="Allowlisted server-side APK signer profile")],
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    Registry(database).set_development_signer_profile(project, profile)
    typer.echo(f"configured development signer profile for {project}")


@app.command("add-track")
def add_track(
    project: Annotated[str, typer.Argument()],
    track: Annotated[str, typer.Argument()],
    role: Annotated[str, typer.Option()] = "development",
    manual_only: Annotated[bool, typer.Option()] = False,
    signer_profile: Annotated[str | None, typer.Option()] = None,
    package: Annotated[str | None, typer.Option(help="Permanently bound Android package")] = None,
    source_branch: Annotated[str | None, typer.Option(help="Permanently bound source branch")] = None,
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    if role not in {"production", "development"}:
        raise typer.BadParameter("role must be production or development")
    Registry(database).add_track(project, track, role, manual_only, signer_profile, package, source_branch)
    typer.echo(f"registered track {project}/{track}")


@app.command("create-token")
def create_token(
    project: Annotated[str, typer.Argument()],
    track: Annotated[
        str,
        typer.Option(help="Exact development track or Root-authorized prefix such as feat-*"),
    ],
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    identifier, token = Registry(database).create_token(project, track)
    typer.echo(f"token id: {identifier}")
    typer.echo(token)
    typer.echo("This is the only time the raw token is displayed; store it in a secret provider.")


@app.command("disable-token")
def disable_token(
    token_id: Annotated[str, typer.Argument(help="Public token identifier, never the raw token")],
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    Registry(database).disable_token(token_id)
    typer.echo(f"disabled upload token {token_id}")


@app.command("import-policy")
def import_policy(
    project: Annotated[str, typer.Argument()],
    event_file: Annotated[Path, typer.Argument(exists=True, readable=True)],
    database: Annotated[Path, typer.Option()] = DEFAULT_DATABASE,
) -> None:
    settings = Settings(database=database, backend="local")
    service = build_service(settings)
    event_id = service.import_policy(project, event_file.read_text())
    typer.echo(event_id)


@app.command("publish-build")
def publish_build(
    apk: Annotated[Path, typer.Argument(exists=True, readable=True)],
    track: Annotated[str, typer.Option(help="Permanent APK publication track")],
    branch: Annotated[str, typer.Option(help="Git branch or worktree represented by this build")],
    commit: Annotated[str, typer.Option()],
    project: Annotated[str | None, typer.Option(help="Project slug; read from --config if omitted")] = None,
    config: Annotated[
        Path | None,
        typer.Option(exists=True, readable=True, help="Project config used for project and service settings"),
    ] = None,
    nsec_env: Annotated[
        str | None, typer.Option(help="Override the environment variable from --config")
    ] = None,
    upload_token_env: Annotated[
        str | None, typer.Option(help="Override the scoped upload-token environment variable from --config")
    ] = None,
    server_url: Annotated[str | None, typer.Option(help="Override the APKTrack URL from --config")] = None,
    idempotency_key: Annotated[str | None, typer.Option()] = None,
    wait: Annotated[
        bool, typer.Option("--wait/--no-wait", help="Wait for verified publication or failure")
    ] = True,
    wait_timeout: Annotated[int, typer.Option(min=1)] = 2700,
    poll_seconds: Annotated[float, typer.Option(min=0.1)] = 2.0,
    github_ci_run: Annotated[
        int | None, typer.Option(min=1, help="Authorize with GitHub OIDC for this source run")
    ] = None,
) -> None:
    import os

    configured = load_project_config(config) if config is not None else None
    if configured is not None:
        if project is not None and project != configured.project.slug:
            raise typer.BadParameter("--project differs from the project slug in --config")
        project = configured.project.slug
        server_url = server_url or str(configured.apktrack.url)
        nsec_env = nsec_env or configured.apktrack.nsec_env
        upload_token_env = upload_token_env or configured.apktrack.upload_token_env
    if project is None:
        raise typer.BadParameter("--project is required unless --config supplies it")
    server_url = server_url or DEFAULT_SERVER_URL
    nsec_env = nsec_env or "APKTRACK_AGENT_NSEC_HEX"
    upload_token_env = upload_token_env or "APKTRACK_UPLOAD_TOKEN"

    secret = (
        secrets.token_hex(32)
        if github_ci_run is not None
        else (os.environ.get(nsec_env) or secrets.token_hex(32))
    )
    if len(secret) != 64 or any(character not in "0123456789abcdefABCDEF" for character in secret):
        raise typer.BadParameter(f"{nsec_env} must contain a 32-byte hexadecimal nsec")
    upload_token = os.environ.get(upload_token_env)
    if not upload_token and github_ci_run is None:
        raise typer.BadParameter(
            f"{upload_token_env} must contain an operator-provisioned project/track-scoped upload token"
        )
    request = BuildRequest(
        project=project,
        track=track,
        branch=branch,
        commit=commit,
        idempotency_key=idempotency_key or f"{project}-{track}-{commit.lower()}",
    )
    effective_idempotency_key = request.idempotency_key
    commit = request.commit
    digest, _size = sha256_file(str(apk))
    if github_ci_run is not None:
        from .ci import CIRequest
        from .ci_client import exchange

        grant = exchange(
            server_url,
            "grants",
            CIRequest(
                build=request,
                source_run_id=github_ci_run,
                apk_sha256=digest,
            ),
        )
        upload_token = str(grant["upload_token"])
    url = httpx.URL(f"{server_url.rstrip('/')}/v2/builds/{project}/{track}")
    for key, value in (
        ("branch", branch),
        ("commit", commit),
        ("idempotency_key", effective_idempotency_key),
    ):
        url = url.copy_add_param(key, value)
    authorization = nip98_header(
        secret,
        url=str(url),
        method="POST",
        payload_sha256=digest,
        now=int(time.time()),
    )
    with apk.open("rb") as stream:
        response = httpx.post(
            url,
            headers={
                "Authorization": authorization,
                "X-APKTrack-Token": upload_token or "",
                "Content-Type": "application/vnd.android.package-archive",
            },
            content=stream,
            timeout=300,
        )
    if response.status_code != 202:
        typer.echo(response.text, err=True)
        raise typer.Exit(1)
    job = Job.model_validate_json(response.text)
    if not wait:
        typer.echo(job.model_dump_json())
        return

    deadline = time.monotonic() + wait_timeout
    status_url = f"{server_url.rstrip('/')}/v2/builds/{job.id}"
    while job.status in {JobStatus.QUEUED, JobStatus.LEASED} or (
        job.status == JobStatus.PUBLISHED and not job.receipt_delivered
    ):
        if time.monotonic() >= deadline:
            typer.echo(job.model_dump_json(), err=True)
            typer.echo("timed out waiting for verified publication", err=True)
            raise typer.Exit(2)
        time.sleep(poll_seconds)
        status_response = httpx.get(status_url, timeout=30)
        if status_response.status_code != 200:
            typer.echo(status_response.text, err=True)
            raise typer.Exit(1)
        job = Job.model_validate_json(status_response.text)

    typer.echo(job.model_dump_json())
    if job.status != JobStatus.PUBLISHED or not job.receipt_delivered:
        raise typer.Exit(2)


@app.command("publish-manual")
def publish_manual(
    apk: Annotated[Path, typer.Argument(exists=True, readable=True)],
    project: Annotated[str, typer.Option()],
    track: Annotated[str, typer.Option(help="Exact manual-only production track")],
    branch: Annotated[str, typer.Option(help="Git branch represented by this build")],
    commit: Annotated[str, typer.Option()],
    confirm_production: Annotated[
        bool,
        typer.Option("--confirm-production", help="Explicitly authorize this production release"),
    ] = False,
    idempotency_key: Annotated[str | None, typer.Option()] = None,
) -> None:
    """Submit and process exactly one production job on the private operator plane."""
    if not confirm_production:
        raise typer.BadParameter("--confirm-production is required for a production release")
    service = build_service(Settings())
    configured_track = service.registry.track(project, track)
    if configured_track["role"] != "production" or not bool(configured_track["manual_only"]):
        raise typer.BadParameter("target must be a configured manual-only production track")
    request = BuildRequest(
        project=project,
        track=track,
        branch=branch,
        commit=commit,
        idempotency_key=idempotency_key or f"{project}-{track}-{commit.lower()}",
    )
    submitted = service.submit(request, apk)
    completed = service.process_one(
        f"manual-production-{submitted.id}",
        allow_manual=True,
        job_id=submitted.id,
    )
    if completed is None:
        raise typer.BadParameter("the named production job could not be leased")
    service.flush_receipt_outbox()
    completed = service.registry.job(completed.id)
    typer.echo(completed.model_dump_json())
    if completed.status != JobStatus.PUBLISHED or not completed.receipt_delivered:
        raise typer.Exit(2)


@app.command("verify")
def verify(
    apk: Annotated[Path, typer.Argument(exists=True, readable=True)],
    policy_events: Annotated[list[Path], typer.Option("--policy-event", exists=True, readable=True)],
    root: Annotated[str, typer.Option(help="Pinned project npub or hex pubkey")],
    project: Annotated[str, typer.Option()],
    track: Annotated[str, typer.Option(help="Permanent APK publication track")],
    role: Annotated[str, typer.Option()],
    expected_sha256: Annotated[str, typer.Option()],
    minimum_policy_version: Annotated[int, typer.Option()] = 1,
    apksigner: Annotated[str, typer.Option()] = "apksigner",
    aapt: Annotated[str, typer.Option()] = "aapt",
) -> None:
    events = [NostrEvent.model_validate_json(path.read_text()) for path in policy_events]
    latest = select_latest_policy(events, root, project)
    latest_document = json.loads(latest.content)
    if int(latest_document["version"]) < minimum_policy_version:
        typer.echo("policy tip is below the locally required minimum version", err=True)
        raise typer.Exit(2)
    result = verify_release(
        apk,
        expected_sha256,
        latest,
        root,
        project,
        track,
        role,
        AndroidSdkApkInspector(apksigner, aapt),
    )
    typer.echo(result.model_dump_json(indent=2))
    if not result.ok:
        raise typer.Exit(2)


@app.command("build-status")
def build_status(
    job_id: Annotated[str, typer.Argument()],
    server_url: Annotated[str, typer.Option()] = DEFAULT_SERVER_URL,
) -> None:
    """Read the status of one unguessable job identifier."""
    response = httpx.get(
        f"{server_url.rstrip('/')}/v2/builds/{job_id}",
        timeout=30,
    )
    if response.status_code != 200:
        typer.echo(response.text, err=True)
        raise typer.Exit(1)
    typer.echo(response.text)


@app.command("reserve-version")
def reserve_version(
    track: Annotated[str, typer.Option(help="Development publication track")],
    branch: Annotated[str, typer.Option(help="Git branch or worktree represented by this build")],
    commit: Annotated[str, typer.Option()],
    project: Annotated[str | None, typer.Option()] = None,
    config: Annotated[
        Path | None,
        typer.Option(exists=True, readable=True, help="Project config supplying APKTrack settings"),
    ] = None,
    upload_token_env: Annotated[str | None, typer.Option()] = None,
    server_url: Annotated[str | None, typer.Option()] = None,
    idempotency_key: Annotated[str | None, typer.Option()] = None,
    minimum: Annotated[int, typer.Option(min=1, max=2_100_000_000)] = 1,
    json_output: Annotated[bool, typer.Option("--json", help="Print the complete reservation")] = False,
    github_ci_run: Annotated[
        int | None, typer.Option(min=1, help="Authorize with GitHub OIDC for this source run")
    ] = None,
) -> None:
    """Atomically reserve the next versionCode for one development track."""
    import os

    configured = load_project_config(config) if config is not None else None
    if configured is not None:
        if project is not None and project != configured.project.slug:
            raise typer.BadParameter("--project differs from the project slug in --config")
        project = configured.project.slug
        server_url = server_url or str(configured.apktrack.url)
        upload_token_env = upload_token_env or configured.apktrack.upload_token_env
    if project is None:
        raise typer.BadParameter("--project is required unless --config supplies it")
    server_url = server_url or DEFAULT_SERVER_URL
    upload_token_env = upload_token_env or "APKTRACK_UPLOAD_TOKEN"
    token = os.environ.get(upload_token_env)
    if not token and github_ci_run is None:
        raise typer.BadParameter(f"{upload_token_env} must contain a scoped upload token")
    request = BuildRequest(
        project=project,
        track=track,
        branch=branch,
        commit=commit,
        idempotency_key=idempotency_key or f"{project}-{track}-{commit.lower()}",
    )
    if github_ci_run is not None:
        from .ci import CIRequest
        from .ci_client import exchange

        result = exchange(server_url, "reservations", CIRequest(build=request, source_run_id=github_ci_run))
        reservation = VersionReservation.model_validate(result)
        typer.echo(reservation.model_dump_json() if json_output else str(reservation.version_code))
        return
    url = httpx.URL(f"{server_url.rstrip('/')}/v2/versions/{request.project}/{request.track}/reservations")
    for key, value in (
        ("branch", request.branch),
        ("commit", request.commit),
        ("idempotency_key", request.idempotency_key),
        ("minimum", str(minimum)),
    ):
        url = url.copy_add_param(key, value)
    response = httpx.post(url, headers={"X-APKTrack-Token": token or ""}, timeout=30)
    if response.status_code not in {200, 201}:
        typer.echo(response.text, err=True)
        raise typer.Exit(1)
    reservation = VersionReservation.model_validate_json(response.text)
    typer.echo(reservation.model_dump_json() if json_output else str(reservation.version_code))


@app.command("worker")
def worker(
    worker_id: Annotated[str, typer.Option()] = "local-worker",
    allow_manual: Annotated[
        bool, typer.Option(help="Explicitly permit manual-only production tracks")
    ] = False,
    watch: Annotated[bool, typer.Option(help="Keep polling the SQLite queue")] = False,
    poll_seconds: Annotated[float, typer.Option(min=0.1)] = 2.0,
) -> None:
    service = build_service(Settings())
    service.prune_staging()
    while True:
        job = service.process_one(worker_id, allow_manual=allow_manual)
        try:
            service.flush_receipt_outbox()
        except AdapterError as exc:
            if not watch:
                raise
            typer.echo(f"receipt delivery pending; retrying: {exc}", err=True)
        if job is not None:
            typer.echo(job.model_dump_json(indent=2))
        elif not watch:
            typer.echo("no queued job")
        if not watch:
            return
        time.sleep(poll_seconds)


@app.command("sync-site")
def sync_site(
    directory: Annotated[Path, typer.Argument(exists=True, file_okay=False, readable=True)],
    require_existing: Annotated[
        bool,
        typer.Option(help="Refuse uploads; every content hash must already exist on Blossom"),
    ] = False,
    defer_manifest: Annotated[
        bool,
        typer.Option(help="Record an outbox update without requesting an operational signature"),
    ] = False,
) -> None:
    """Upload the immutable app shell; releases are discovered from signed receipts."""
    count, changed = build_service(Settings()).sync_site(
        directory,
        upload_missing=not require_existing,
        publish_manifest=not defer_manifest,
    )
    typer.echo(json.dumps({"files": count, "changed": changed, "manifest_deferred": defer_manifest}))


@app.command("gc")
def gc(
    grace_seconds: Annotated[int, typer.Option(min=0)] = 7 * 24 * 3600,
) -> None:
    deleted = build_service(Settings()).garbage_collect(grace_seconds)
    typer.echo(json.dumps({"deleted": deleted}))


@app.command("prune-staging")
def prune_staging(
    grace_seconds: Annotated[int, typer.Option(min=0)] = 3600,
) -> None:
    """Remove terminal or orphaned local APK staging files."""
    deleted = build_service(Settings()).prune_staging(grace_seconds)
    typer.echo(json.dumps({"deleted": deleted, "count": len(deleted)}))


@app.command("serve")
def serve(
    host: Annotated[str, typer.Option()] = "127.0.0.1",
    port: Annotated[int, typer.Option()] = 8000,
) -> None:
    import uvicorn

    uvicorn.run("apktrack.api:app", host=host, port=port)


def main() -> None:
    try:
        app()
    except APKTrackError as exc:
        typer.echo(str(exc), err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
