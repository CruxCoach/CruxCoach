import hashlib
import hmac
import json
from typing import Any

from coincurve import PrivateKey, PublicKeyXOnly

from .canonical import canonical_json
from .errors import ValidationError
from .models import NostrEvent


def decode_npub(value: str) -> str:
    """Decode a bech32 npub without accepting mixed case or non-npub HRPs."""
    if value.startswith("npub1"):
        if value.lower() != value and value.upper() != value:
            raise ValidationError("mixed-case npub")
        value = value.lower()
        pos = value.rfind("1")
        hrp, data_part = value[:pos], value[pos + 1 :]
        if hrp != "npub" or len(data_part) < 7:
            raise ValidationError("invalid npub")
        alphabet = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
        try:
            data = [alphabet.index(char) for char in data_part]
        except ValueError as exc:
            raise ValidationError("invalid npub character") from exc
        if _bech32_polymod(_bech32_hrp_expand(hrp) + data) != 1:
            raise ValidationError("invalid npub checksum")
        decoded = _convertbits(data[:-6], 5, 8, False)
        if decoded is None or len(decoded) != 32:
            raise ValidationError("npub must encode 32 bytes")
        return bytes(decoded).hex()
    if len(value) == 64:
        try:
            bytes.fromhex(value)
        except ValueError as exc:
            raise ValidationError("invalid hexadecimal pubkey") from exc
        return value.lower()
    raise ValidationError("root identity must be npub or 64-character hex")


def encode_npub(value: str) -> str:
    """Encode a validated 32-byte hexadecimal public key as an npub."""
    pubkey = decode_npub(value)
    alphabet = "qpzry9x8gf2tvdw0s3jn54khce6mua7l"
    data = _convertbits(list(bytes.fromhex(pubkey)), 8, 5, True)
    if data is None:  # pragma: no cover - fixed-width input cannot fail conversion
        raise ValidationError("invalid public key")
    values = _bech32_hrp_expand("npub") + data + [0] * 6
    polymod = _bech32_polymod(values) ^ 1
    checksum = [(polymod >> (5 * (5 - index))) & 31 for index in range(6)]
    return "npub1" + "".join(alphabet[item] for item in [*data, *checksum])


def _bech32_polymod(values: list[int]) -> int:
    generators = (0x3B6A57B2, 0x26508E6D, 0x1EA119FA, 0x3D4233DD, 0x2A1462B3)
    chk = 1
    for value in values:
        top = chk >> 25
        chk = (chk & 0x1FFFFFF) << 5 ^ value
        for index, generator in enumerate(generators):
            if (top >> index) & 1:
                chk ^= generator
    return chk


def _bech32_hrp_expand(hrp: str) -> list[int]:
    return [ord(x) >> 5 for x in hrp] + [0] + [ord(x) & 31 for x in hrp]


def _convertbits(data: list[int], from_bits: int, to_bits: int, pad: bool) -> list[int] | None:
    acc = 0
    bits = 0
    result: list[int] = []
    max_value = (1 << to_bits) - 1
    for value in data:
        if value < 0 or value >> from_bits:
            return None
        acc = (acc << from_bits) | value
        bits += from_bits
        while bits >= to_bits:
            bits -= to_bits
            result.append((acc >> bits) & max_value)
    if pad:
        if bits:
            result.append((acc << (to_bits - bits)) & max_value)
    elif bits >= from_bits or ((acc << (to_bits - bits)) & max_value):
        return None
    return result


def event_preimage(pubkey: str, created_at: int, kind: int, tags: list[list[str]], content: str) -> bytes:
    return json.dumps(
        [0, pubkey, created_at, kind, tags, content],
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode()


def event_id(pubkey: str, created_at: int, kind: int, tags: list[list[str]], content: str) -> str:
    return hashlib.sha256(event_preimage(pubkey, created_at, kind, tags, content)).hexdigest()


def verify_event(event: NostrEvent) -> bool:
    tags = [list(tag) for tag in event.tags]
    expected = event_id(event.pubkey, event.created_at, event.kind, tags, event.content)
    if not hmac.compare_digest(expected, event.id):
        return False
    try:
        return PublicKeyXOnly(bytes.fromhex(event.pubkey)).verify(
            bytes.fromhex(event.sig), bytes.fromhex(event.id)
        )
    except (ValueError, TypeError):
        return False


def sign_event(
    secret_hex: str, created_at: int, kind: int, tags: list[list[str]], content: str
) -> NostrEvent:
    private_key = PrivateKey(bytes.fromhex(secret_hex))
    pubkey = PublicKeyXOnly.from_secret(private_key.secret).format().hex()
    identifier = event_id(pubkey, created_at, kind, tags, content)
    signature = private_key.sign_schnorr(bytes.fromhex(identifier)).hex()
    return NostrEvent(
        id=identifier,
        pubkey=pubkey,
        created_at=created_at,
        kind=kind,
        tags=tuple(tuple(tag) for tag in tags),
        content=content,
        sig=signature,
    )


def event_dict(event: NostrEvent) -> dict[str, Any]:
    return event.model_dump(mode="json")


def event_json(event: NostrEvent) -> str:
    return canonical_json(event_dict(event)).decode().rstrip("\n")
