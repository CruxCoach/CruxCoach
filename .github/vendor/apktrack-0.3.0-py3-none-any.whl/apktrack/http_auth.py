import base64
import binascii
import json

from .errors import ValidationError
from .models import NostrEvent
from .nostr import verify_event

NIP98_KIND = 27235


def verify_nip98(
    authorization: str | None,
    *,
    url: str,
    method: str,
    payload_sha256: str,
    now: int,
    max_clock_skew: int = 60,
) -> str:
    """Verify a NIP-98 HTTP authorization and return its untrusted transport pubkey."""
    if authorization is None or not authorization.startswith("Nostr "):
        raise ValidationError("missing NIP-98 authorization")
    encoded = authorization.removeprefix("Nostr ")
    if not encoded or len(encoded) > 16_384:
        raise ValidationError("invalid NIP-98 authorization size")
    try:
        raw = base64.b64decode(encoded, validate=True)
        event = NostrEvent.model_validate_json(raw)
    except (binascii.Error, ValueError) as exc:
        raise ValidationError("invalid NIP-98 authorization encoding") from exc
    if event.kind != NIP98_KIND or event.content != "" or not verify_event(event):
        raise ValidationError("invalid NIP-98 event")
    if abs(event.created_at - now) > max_clock_skew:
        raise ValidationError("NIP-98 authorization is outside the accepted time window")
    expected = {"u": url, "method": method.upper(), "payload": payload_sha256}
    for name, value in expected.items():
        matches = [tag[1] for tag in event.tags if len(tag) == 2 and tag[0] == name]
        if matches != [value]:
            raise ValidationError(f"NIP-98 {name} tag is missing, duplicated, or mismatched")
    allowed = {"u", "method", "payload"}
    if any(not tag or tag[0] not in allowed for tag in event.tags):
        raise ValidationError("NIP-98 event contains unsupported tags")
    return event.pubkey


def nip98_header(secret_hex: str, *, url: str, method: str, payload_sha256: str, now: int) -> str:
    from .nostr import event_dict, sign_event

    event = sign_event(
        secret_hex,
        now,
        NIP98_KIND,
        [["u", url], ["method", method.upper()], ["payload", payload_sha256]],
        "",
    )
    payload = json.dumps(event_dict(event), separators=(",", ":")).encode()
    return "Nostr " + base64.b64encode(payload).decode()
