import base64
import hmac
import json
from typing import Any

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec, ed25519, padding, rsa

from .canonical import canonical_json, sha256_bytes
from .errors import ValidationError
from .models import ApkIdentity, NostrEvent, PolicyDocument
from .nostr import decode_npub, verify_event

POLICY_KIND = 30078
POLICY_D_PREFIX = "apktrack-policy:"
CROSS_SIGNATURE_DOMAIN = b"apktrack-policy-cross-signature-v1\n"


def policy_unsigned_dict(policy: PolicyDocument) -> dict[str, Any]:
    value = policy.model_dump(mode="json")
    if policy.schema_version == 1:
        for rule in value["certificates"]:
            rule.pop("track_patterns", None)
            rule.pop("package_patterns", None)
    value["cross_signatures"] = []
    return value


def policy_hash(policy: PolicyDocument) -> str:
    return sha256_bytes(canonical_json(policy_unsigned_dict(policy)))


def cross_signature_challenge(policy: PolicyDocument) -> bytes:
    return CROSS_SIGNATURE_DOMAIN + policy_hash(policy).encode() + b"\n"


def verify_cross_signatures(policy: PolicyDocument) -> list[str]:
    errors: list[str] = []
    allowed = {rule.certificate_sha256 for rule in policy.certificates}
    challenge = cross_signature_challenge(policy)
    for proof in policy.cross_signatures:
        try:
            certificate = x509.load_pem_x509_certificate(proof.certificate_pem.encode())
            fingerprint = certificate.fingerprint(hashes.SHA256()).hex()
            if not hmac.compare_digest(fingerprint, proof.certificate_sha256):
                raise ValidationError("certificate PEM fingerprint differs from proof fingerprint")
            if fingerprint not in allowed:
                raise ValidationError("cross-signature certificate is absent from allowlist")
            signature = base64.b64decode(proof.signature_base64, validate=True)
            public_key = certificate.public_key()
            if proof.algorithm == "rsa-pkcs1v15-sha256" and isinstance(public_key, rsa.RSAPublicKey):
                public_key.verify(signature, challenge, padding.PKCS1v15(), hashes.SHA256())
            elif proof.algorithm == "ecdsa-sha256" and isinstance(public_key, ec.EllipticCurvePublicKey):
                public_key.verify(signature, challenge, ec.ECDSA(hashes.SHA256()))
            elif proof.algorithm == "ed25519" and isinstance(public_key, ed25519.Ed25519PublicKey):
                public_key.verify(signature, challenge)
            else:
                raise ValidationError("algorithm does not match certificate public key")
        except (ValueError, InvalidSignature, ValidationError) as exc:
            errors.append(f"cross-signature {proof.certificate_sha256}: {exc}")
    return errors


def parse_and_verify_policy_event(
    event: NostrEvent, trusted_root: str, expected_project: str
) -> PolicyDocument:
    if event.kind != POLICY_KIND:
        raise ValidationError(f"policy event kind must be {POLICY_KIND}")
    root_hex = decode_npub(trusted_root)
    if not hmac.compare_digest(event.pubkey, root_hex):
        raise ValidationError("policy event author is not the configured root identity")
    d_tags = [tag for tag in event.tags if len(tag) == 2 and tag[0] == "d"]
    if d_tags != [("d", f"{POLICY_D_PREFIX}{expected_project}")]:
        raise ValidationError("policy event has missing or incorrect d tag")
    if not verify_event(event):
        raise ValidationError("invalid Nostr event id or Schnorr signature")
    try:
        policy = PolicyDocument.model_validate_json(event.content)
    except ValueError as exc:
        raise ValidationError(f"invalid policy content: {exc}") from exc
    if policy.project != expected_project:
        raise ValidationError("policy content project differs from event address")
    expected_content = canonical_json(json.loads(event.content)).decode()
    if event.content != expected_content:
        raise ValidationError("policy content is not in the protocol's canonical JSON form")
    return policy


def authorize_apk(
    policy: PolicyDocument,
    identity: ApkIdentity,
    track: str,
    role: str,
    now: int,
) -> None:
    if policy.valid_from is not None and now < policy.valid_from:
        raise ValidationError("policy is not valid yet")
    if policy.valid_until is not None and now >= policy.valid_until:
        raise ValidationError("policy has expired")
    for rule in policy.certificates:
        if not package_is_allowed(rule.package_name, rule.package_patterns, identity.package_name):
            continue
        if not hmac.compare_digest(rule.certificate_sha256, identity.certificate_sha256):
            continue
        if role not in rule.roles:
            continue
        if not track_is_allowed(rule.tracks, rule.track_patterns, track):
            continue
        if rule.valid_from is not None and now < rule.valid_from:
            continue
        if rule.valid_until is not None and now >= rule.valid_until:
            continue
        return
    raise ValidationError("APK package/certificate/role/track is not allowed by latest policy")


def track_is_allowed(tracks: tuple[str, ...], patterns: tuple[str, ...], track: str) -> bool:
    return track in tracks or any(track.startswith(pattern[:-1]) for pattern in patterns)


def package_is_allowed(package: str, patterns: tuple[str, ...], candidate: str) -> bool:
    return candidate == package or any(candidate.startswith(pattern[:-1]) for pattern in patterns)


def dynamic_track_role(
    policy: PolicyDocument,
    identity: ApkIdentity,
    track: str,
    now: int,
) -> str:
    """Resolve a not-yet-provisioned track only from a schema-2 wildcard rule.

    Exact track entries never create registry state implicitly. Dynamic production
    tracks are deliberately forbidden: production remains an explicit manual act.
    """
    roles: set[str] = set()
    for rule in policy.certificates:
        if not package_is_allowed(rule.package_name, rule.package_patterns, identity.package_name):
            continue
        if not hmac.compare_digest(rule.certificate_sha256, identity.certificate_sha256):
            continue
        if not any(track.startswith(pattern[:-1]) for pattern in rule.track_patterns):
            continue
        if rule.valid_from is not None and now < rule.valid_from:
            continue
        if rule.valid_until is not None and now >= rule.valid_until:
            continue
        roles.update(rule.roles)
    if roles != {"development"}:
        raise ValidationError("unknown track is not covered by one unambiguous development pattern")
    return "development"


def dynamic_track_role_for_server_signing(
    policy: PolicyDocument,
    package_name: str,
    track: str,
    now: int,
) -> str:
    """Resolve a dynamic development scope before a trusted server signer runs.

    The candidate's transport signature is intentionally irrelevant here. The
    fully signed output still passes authorize_apk afterwards, including the
    exact Root-allowlisted certificate fingerprint.
    """
    roles: set[str] = set()
    for rule in policy.certificates:
        if not package_is_allowed(rule.package_name, rule.package_patterns, package_name):
            continue
        if not any(track.startswith(pattern[:-1]) for pattern in rule.track_patterns):
            continue
        if rule.valid_from is not None and now < rule.valid_from:
            continue
        if rule.valid_until is not None and now >= rule.valid_until:
            continue
        roles.update(rule.roles)
    if roles != {"development"}:
        raise ValidationError("unknown track is not covered by one unambiguous development pattern")
    return "development"
