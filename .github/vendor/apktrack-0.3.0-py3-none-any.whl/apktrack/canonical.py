import hashlib
import json
from collections.abc import Mapping, Sequence
from typing import Any

from .errors import ValidationError


def _reject_unsupported(value: Any) -> None:
    if isinstance(value, float):
        raise ValidationError("floating point values are forbidden in canonical documents")
    if value is None or isinstance(value, (str, int, bool)):
        return
    if isinstance(value, Mapping):
        for key, child in value.items():
            if not isinstance(key, str):
                raise ValidationError("canonical object keys must be strings")
            _reject_unsupported(child)
        return
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes, bytearray)):
        for child in value:
            _reject_unsupported(child)
        return
    raise ValidationError(f"unsupported canonical value: {type(value).__name__}")


def canonical_json(value: Any) -> bytes:
    """Project canonical JSON: UTF-8, sorted keys, compact, no floats, one trailing LF."""
    _reject_unsupported(value)
    return (json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n").encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: str, chunk_size: int = 1024 * 1024) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with open(path, "rb") as stream:
        while chunk := stream.read(chunk_size):
            digest.update(chunk)
            size += len(chunk)
    return digest.hexdigest(), size
