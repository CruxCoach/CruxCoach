"""CommandEventSigner bridge to a remote NIP-46 signer through `nak`.

The remote signer connection is read by nak from NOSTR_SECRET_KEY. It is never
placed in argv. APKTRACK_OPERATIONAL_PUBKEY is public configuration and lets
APKTrack check that Amber signed with the expected nsite identity.
"""

import json
import os
import re
import subprocess
import sys

HEX64 = re.compile(r"^[0-9a-f]{64}$")


def public_key() -> str:
    value = os.environ.get("APKTRACK_OPERATIONAL_PUBKEY", "").lower()
    if not HEX64.fullmatch(value):
        raise RuntimeError("APKTRACK_OPERATIONAL_PUBKEY must be a 64-character hex pubkey")
    return value


def sign_event(payload: str) -> str:
    connection = os.environ.get("NOSTR_SECRET_KEY")
    if not connection or not (connection.startswith("bunker://") or connection.startswith("nbunksec1")):
        raise RuntimeError("NOSTR_SECRET_KEY must contain a NIP-46 bunker connection")
    request = json.loads(payload)
    if set(request) != {"created_at", "kind", "tags", "content"}:
        raise RuntimeError("unexpected unsigned event fields")
    executable = os.environ.get("APKTRACK_NAK", "nak")
    result = subprocess.run(
        [executable, "event"],
        input=json.dumps(request, separators=(",", ":")),
        text=True,
        capture_output=True,
        check=True,
        timeout=120,
    )
    event = json.loads(result.stdout)
    if event.get("pubkey") != public_key():
        raise RuntimeError("NIP-46 signer returned an unexpected public key")
    return json.dumps(event, separators=(",", ":"))


def main() -> None:
    if len(sys.argv) != 2:
        raise SystemExit("usage: nak-nip46-signer get-public-key|sign-event")
    if sys.argv[1] == "get-public-key":
        print(public_key())
        return
    if sys.argv[1] == "sign-event":
        print(sign_event(sys.stdin.read()))
        return
    raise SystemExit("unknown signer action")


if __name__ == "__main__":
    main()
