class APKTrackError(Exception):
    """Expected domain or adapter error safe to return to an API caller."""


class ValidationError(APKTrackError):
    pass


class ConflictError(APKTrackError):
    pass


class NotFoundError(APKTrackError):
    pass


class AdapterError(APKTrackError):
    pass
