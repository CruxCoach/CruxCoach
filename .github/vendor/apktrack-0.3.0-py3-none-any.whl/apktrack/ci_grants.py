"""Opaque, expiring, single-job upload capabilities. Only token hashes are stored."""

import hashlib
import json
import secrets
import sqlite3
from typing import Any, cast

from .ci import read_policy
from .errors import ConflictError
from .models import BuildRequest, unix_now

SCHEMA = """
CREATE TABLE IF NOT EXISTS ci_grants (
  token_hash TEXT PRIMARY KEY,
  project TEXT NOT NULL,
  track TEXT NOT NULL,
  branch TEXT NOT NULL,
  commit_hash TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  apk_sha256 TEXT NOT NULL,
  version_code INTEGER NOT NULL,
  evidence TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  revoked INTEGER NOT NULL DEFAULT 0,
  job_id TEXT,
  UNIQUE(project,idempotency_key)
);
"""


def policy_digest(path: Any) -> str:
    return hashlib.sha256(json.dumps(read_policy(path), sort_keys=True).encode()).hexdigest()


def issue(registry: Any, build: BuildRequest, digest: str, evidence: dict[str, Any]) -> str:
    if not registry.remote_upload_allowed(build.project, build.track):
        raise ConflictError("CI grants cannot authorize production or manual-only tracks")
    reservation = registry.version_reservation(build.project, build.track, build.commit)
    if reservation.branch != build.branch or reservation.idempotency_key != build.idempotency_key:
        raise ConflictError("CI grant requires the exact version reservation")
    token = "ci_" + secrets.token_urlsafe(32)
    key = hashlib.sha256(token.encode()).hexdigest()
    values = (build.project, build.track, build.branch, build.commit, build.idempotency_key, digest)
    with registry.transaction() as db:
        old = db.execute(
            "SELECT * FROM ci_grants WHERE project=? AND idempotency_key=?",
            (build.project, build.idempotency_key),
        ).fetchone()
        if old is not None:
            if (
                old["apk_sha256"] != digest
                or old["branch"] != build.branch
                or old["track"] != build.track
                or old["commit_hash"] != build.commit
                or old["evidence"] != json.dumps(evidence, sort_keys=True)
                or old["revoked"]
            ):
                raise ConflictError("CI publication already bound to a different or revoked request")
            db.execute(
                "UPDATE ci_grants SET token_hash=?,expires_at=? WHERE token_hash=?",
                (key, unix_now() + 300, old["token_hash"]),
            )
        else:
            db.execute(
                "INSERT INTO ci_grants(token_hash,project,track,branch,commit_hash,idempotency_key,"
                "apk_sha256,version_code,evidence,expires_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                (
                    key,
                    *values,
                    reservation.version_code,
                    json.dumps(evidence, sort_keys=True),
                    unix_now() + 300,
                ),
            )
    return token


def check(db: sqlite3.Connection, token: str, build: BuildRequest, digest: str | None = None) -> sqlite3.Row:
    key = hashlib.sha256(token.encode()).hexdigest()
    row = db.execute("SELECT * FROM ci_grants WHERE token_hash=?", (key,)).fetchone()
    if (
        row is None
        or row["revoked"]
        or row["expires_at"] <= unix_now()
        or row["project"] != build.project
        or row["track"] != build.track
        or row["branch"] != build.branch
        or row["commit_hash"] != build.commit
        or row["idempotency_key"] != build.idempotency_key
        or (digest is not None and row["apk_sha256"] != digest)
    ):
        raise ConflictError("invalid, expired, revoked or out-of-scope CI upload grant")
    return cast(sqlite3.Row, row)
