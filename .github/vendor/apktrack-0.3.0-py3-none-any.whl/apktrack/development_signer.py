"""Development APK signing daemon. Requests identify a leased CI job, never a command/key/path."""

import argparse
import json
import os
import re
import shutil
import socket
import socketserver
import stat
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from . import ci_grants
from .canonical import canonical_json, sha256_file
from .errors import ValidationError
from .models import unix_now
from .policy import package_is_allowed
from .sandbox_inspector import SandboxedAndroidInspector
from .storage import ReadOnlyRegistry
from .verification import verify_release


class DevelopmentSigner:
    def __init__(self, options: dict[str, Any]) -> None:
        self.options = options
        self.registry = ReadOnlyRegistry(Path(options["database"]))
        self.inspector = SandboxedAndroidInspector(Path(options["build_tools"]))

    def sign_job(self, request: dict[str, Any]) -> str:
        if set(request) != {"job_id", "candidate_sha256", "profile"}:
            raise ValidationError("unsupported signing request")
        job = self.registry.job(request["job_id"])
        if job.status != "leased" or job.candidate_sha256 != request["candidate_sha256"]:
            raise ValidationError("signing requires an exact leased job")
        if job.project != self.options["project"] or request["profile"] != self.options["profile"]:
            raise ValidationError("development signer scope mismatch")
        if not self.registry.remote_upload_allowed(job.project, job.track):
            raise ValidationError("production signing is unavailable")
        with self.registry.connect() as db:
            grant = db.execute("SELECT * FROM ci_grants WHERE job_id=?", (job.id,)).fetchone()
        if grant is None or grant["revoked"]:
            raise ValidationError("signing requires an unrevoked CI authorization")
        evidence = json.loads(grant["evidence"])
        policy_path = Path(self.options["ci_policy"])
        if ci_grants.policy_digest(policy_path) != evidence["policy_sha256"]:
            raise ValidationError("CI authorization has changed")
        policy_event, policy = self.registry.latest_policy(job.project)
        source_path = Path(self.options["staging"]) / f"{job.candidate_sha256}.apk"
        descriptor = os.open(source_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        output_root = Path(self.options["outputs"])
        output_root.mkdir(parents=True, exist_ok=True)
        with os.fdopen(descriptor, "rb") as source, tempfile.TemporaryDirectory(dir=output_root) as directory:
            source_stat = os.fstat(source.fileno())
            if not stat.S_ISREG(source_stat.st_mode) or source_stat.st_size != job.size:
                raise ValidationError("candidate must be the admitted regular APK file")
            work = Path(directory)
            snapshot = work / "input.apk"
            with snapshot.open("wb") as target:
                shutil.copyfileobj(source, target)
            if sha256_file(str(snapshot)) != (job.candidate_sha256, job.size):
                raise ValidationError("candidate bytes changed")
            identity = self.inspector.inspect(snapshot)
            if (
                identity.package_name != evidence["package_name"]
                or identity.version_code != grant["version_code"]
            ):
                raise ValidationError("candidate package/version not authorized")
            project = self.registry.project(job.project)
            if project["root_identity"] != self.options["root_identity"]:
                raise ValidationError("project Root differs from the private signer pin")
            roles: set[str] = set()
            for rule in policy.certificates:
                if (
                    package_is_allowed(rule.package_name, rule.package_patterns, identity.package_name)
                    and (
                        job.track in rule.tracks
                        or any(job.track.startswith(p[:-1]) for p in rule.track_patterns)
                    )
                    and (rule.valid_from is None or rule.valid_from <= unix_now())
                    and (rule.valid_until is None or unix_now() < rule.valid_until)
                ):
                    roles.update(rule.roles)
            if roles != {"development"}:
                raise ValidationError("package is not exclusively Development-authorized")
            # The signing JVM sees only its dedicated Android Development credential,
            # no Nostr keys, host home directories, sockets or network.
            command = self.inspector.command(["/tools/apksigner", str(snapshot)])
            command = command[: command.index("--")]
            command += [
                "--bind",
                str(work),
                "/work",
                "--ro-bind",
                self.options["keystore_credential"],
                "/dev-key.jks",
                "--ro-bind",
                self.options["password_credential"],
                "/dev-key-password",
                "--",
                "/tools/apksigner",
                "sign",
                "--ks",
                "/dev-key.jks",
                "--ks-pass",
                "file:/dev-key-password",
                "--ks-key-alias",
                self.options["alias"],
                "--out",
                "/work/signed.apk",
                "/input.apk",
            ]
            try:
                subprocess.run(
                    command,
                    check=True,
                    capture_output=True,
                    timeout=300,
                    env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"},
                )
            except (OSError, subprocess.SubprocessError) as exc:
                raise ValidationError("isolated Development signing failed") from exc
            signed = work / "signed.apk"
            digest, _size = sha256_file(str(signed))
            project = self.registry.project(job.project)
            result = verify_release(
                signed,
                digest,
                policy_event,
                project["root_identity"],
                job.project,
                job.track,
                "development",
                self.inspector,
            )
            if (
                not result.ok
                or result.identity is None
                or result.identity.package_name != identity.package_name
                or result.identity.version_code != identity.version_code
            ):
                raise ValidationError("signed output failed Development verification")
            if ci_grants.policy_digest(policy_path) != evidence["policy_sha256"]:
                raise ValidationError("authorization changed during signing")
            destination = output_root / f"{digest}.apk"
            signed.replace(destination)
            os.chmod(destination, 0o640)
            return digest


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--serve", type=Path)
    parser.add_argument("--socket", type=Path)
    parser.add_argument("--outputs", type=Path)
    parser.add_argument("--profile")
    parser.add_argument("--in", dest="source", type=Path)
    parser.add_argument("--out", dest="destination", type=Path)
    args = parser.parse_args()
    if args.serve:
        options = json.loads(args.serve.read_text())
        signer = DevelopmentSigner(options)

        class Handler(socketserver.StreamRequestHandler):
            def handle(self) -> None:
                self.connection.settimeout(330)
                try:
                    raw = self.rfile.readline(4097)
                    if len(raw) > 4096 or not raw.endswith(b"\n"):
                        raise ValueError("oversized request")
                    result = {"sha256": signer.sign_job(json.loads(raw))}
                except Exception:
                    result = {"error": "Development signing request rejected"}
                self.wfile.write(canonical_json(result) + b"\n")

        socket_path = Path(options["socket"])
        socket_path.parent.mkdir(parents=True, exist_ok=True)
        with socketserver.UnixStreamServer(str(socket_path), Handler) as server:
            os.chmod(socket_path, 0o660)
            try:
                server.serve_forever()
            finally:
                socket_path.unlink(missing_ok=True)
        return
    if any(v is None for v in (args.socket, args.outputs, args.profile, args.source, args.destination)):
        parser.error("client requires --socket, --outputs, --profile, --in and --out")
    match = re.fullmatch(r"signed-([0-9a-f]{32})\.apk", args.destination.name)
    if match is None:
        parser.error("destination must identify an APKTrack job")
    digest, _size = sha256_file(str(args.source))
    request = {"job_id": match[1], "profile": args.profile, "candidate_sha256": digest}
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
        connection.settimeout(330)
        connection.connect(str(args.socket))
        connection.sendall(canonical_json(request) + b"\n")
        with connection.makefile("rb") as stream:
            result = json.loads(stream.readline(4097))
    sha = result.get("sha256", "")
    if not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise SystemExit("Development signing request rejected")
    shutil.copyfile(args.outputs / f"{sha}.apk", args.destination)
    if sha256_file(str(args.destination))[0] != sha:
        args.destination.unlink()
        raise SystemExit("Development signed output mismatch")
