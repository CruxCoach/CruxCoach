import json
import mimetypes
import re
import tempfile
import threading
import time
from pathlib import Path

from . import ci_grants
from .canonical import canonical_json, sha256_bytes, sha256_file
from .errors import ConflictError, NotFoundError, ValidationError
from .models import BuildRequest, Job, JobStatus, NostrEvent, ReleaseMetadata, unix_now
from .nostr import encode_npub
from .nsite import ROOT_MANIFEST_KIND, SNAPSHOT_KIND, manifest_tags, snapshot_tags
from .policy import (
    dynamic_track_role,
    dynamic_track_role_for_server_signing,
    parse_and_verify_policy_event,
    verify_cross_signatures,
)
from .ports import ApkInspector, ApkSigner, BlobStore, EventNetwork, EventSigner
from .receipt import release_receipt
from .storage import Registry
from .verification import verify_release


class APKTrackService:
    _CANDIDATE_FILE = re.compile(r"^(?P<sha256>[0-9a-f]{64})\.apk$")
    _SIGNED_FILE = re.compile(r"^signed-(?P<job_id>[0-9a-f]{32})\.apk(?:\.idsig)?$")

    def __init__(
        self,
        registry: Registry,
        staging_directory: Path,
        blob_store: BlobStore,
        event_network: EventNetwork,
        signer: EventSigner,
        inspector: ApkInspector,
        blossom_servers: list[str],
        receipt_signer: EventSigner | None = None,
        receipt_network: EventNetwork | None = None,
        max_apk_bytes: int = 250 * 1024 * 1024,
        apk_signer: ApkSigner | None = None,
        ci_policy_file: Path | None = None,
        lease_seconds: int = 300,
        lease_heartbeat_seconds: float = 60.0,
    ) -> None:
        self.ci_policy_file = ci_policy_file
        self.registry = registry
        self.staging_directory = staging_directory
        self.staging_directory.mkdir(parents=True, exist_ok=True)
        self.blob_store = blob_store
        self.event_network = event_network
        self.signer = signer
        self.receipt_signer = receipt_signer or signer
        self.receipt_network = receipt_network or event_network
        self.inspector = inspector
        self.blossom_servers = blossom_servers
        self.max_apk_bytes = max_apk_bytes
        self.apk_signer = apk_signer
        self.lease_seconds = lease_seconds
        self.lease_heartbeat_seconds = lease_heartbeat_seconds
        self._manifest_lock = threading.Lock()
        self._receipt_lock = threading.Lock()

    def submit(
        self,
        request: BuildRequest,
        source: Path,
        *,
        submitter_pubkey: str | None = None,
        ci_grant: str | None = None,
    ) -> Job:
        self.registry.project(request.project)
        digest, size = sha256_file(str(source))
        if size == 0:
            raise ValidationError("APK candidate is empty")
        if size > self.max_apk_bytes:
            raise ValidationError(f"APK exceeds maximum size of {self.max_apk_bytes} bytes")
        if ci_grant is not None:
            with self.registry.connect() as db:
                ci_grants.check(db, ci_grant, request, digest)
        target = self.staging_directory / f"{digest}.apk"
        if not target.exists():
            with (
                source.open("rb") as source_stream,
                tempfile.NamedTemporaryFile(
                    dir=self.staging_directory, prefix="candidate-", delete=False
                ) as target_stream,
            ):
                temporary = Path(target_stream.name)
                while chunk := source_stream.read(1024 * 1024):
                    target_stream.write(chunk)
            temporary.replace(target)
        return self.registry.enqueue(
            request.project,
            request.track,
            request.branch,
            request.commit,
            request.idempotency_key,
            digest,
            size,
            target,
            submitter_pubkey,
            ci_grant,
        )

    def import_policy(self, project: str, event_json: str) -> str:
        from .models import NostrEvent

        event = NostrEvent.model_validate_json(event_json)
        project_row = self.registry.project(project)
        policy = parse_and_verify_policy_event(event, project_row["root_identity"], project)
        cross_errors = verify_cross_signatures(policy)
        if cross_errors:
            raise ValidationError("; ".join(cross_errors))
        self.registry.store_policy(project, event, policy)
        return event.id

    def process_one(
        self,
        worker_id: str,
        allow_manual: bool = False,
        job_id: str | None = None,
    ) -> Job | None:
        job = (
            self.registry.lease_job(job_id, worker_id, seconds=self.lease_seconds, allow_manual=allow_manual)
            if job_id is not None
            else self.registry.lease(worker_id, seconds=self.lease_seconds, allow_manual=allow_manual)
        )
        if job is None:
            return None
        final_hash = job.candidate_sha256
        heartbeat_stop = threading.Event()
        heartbeat_errors: list[Exception] = []

        def renew_lease() -> None:
            while not heartbeat_stop.wait(self.lease_heartbeat_seconds):
                try:
                    if not self.registry.renew_lease(job.id, worker_id, self.lease_seconds):
                        heartbeat_errors.append(ConflictError("job lease was lost during publication"))
                        return
                except Exception as exc:
                    heartbeat_errors.append(exc)
                    return

        heartbeat = threading.Thread(
            target=renew_lease,
            name=f"apktrack-lease-{job.id}",
            daemon=True,
        )
        heartbeat.start()
        try:
            policy_event, policy = self.registry.latest_policy(job.project)
            project = self.registry.project(job.project)
            apk = self.staging_directory / f"{job.candidate_sha256}.apk"
            final_size = job.size
            provision_role: str | None = None
            with self.registry.connect() as db:
                ci_job = db.execute("SELECT * FROM ci_grants WHERE job_id=?", (job.id,)).fetchone()
            if ci_job is not None:
                evidence = json.loads(ci_job["evidence"])
                if (
                    ci_job["revoked"]
                    or self.ci_policy_file is None
                    or ci_grants.policy_digest(self.ci_policy_file) != evidence["policy_sha256"]
                    or not self.registry.remote_upload_allowed(job.project, job.track)
                ):
                    raise ValidationError("CI authorization revoked before signing")
                candidate = self.inspector.inspect(apk)
                if (
                    candidate.package_name != evidence["package_name"]
                    or candidate.version_code != ci_job["version_code"]
                    or final_hash != ci_job["apk_sha256"]
                ):
                    raise ValidationError("CI APK does not match authorized package/version/hash")
            try:
                track = self.registry.track(job.project, job.track)
                role = str(track["role"])
                signer_profile = track["signer_profile"]
            except NotFoundError:
                candidate_identity = self.inspector.inspect(apk)
                signer_profile = project["development_signer_profile"]
                role = (
                    dynamic_track_role_for_server_signing(
                        policy, candidate_identity.package_name, job.track, unix_now()
                    )
                    if signer_profile is not None
                    else dynamic_track_role(policy, candidate_identity, job.track, unix_now())
                )
                provision_role = role
            if signer_profile is not None:
                if self.apk_signer is None:
                    raise ConflictError("track requires a configured APK signer adapter")
                signed_temporary = self.staging_directory / f"signed-{job.id}.apk"
                self.apk_signer.sign(apk, signed_temporary, str(signer_profile))
                final_hash, final_size = sha256_file(str(signed_temporary))
                if final_size > self.max_apk_bytes:
                    signed_temporary.unlink(missing_ok=True)
                    raise ValidationError("signed APK exceeds configured size limit")
                apk = self.staging_directory / f"{final_hash}.apk"
                signed_temporary.replace(apk)
            result = verify_release(
                apk=apk,
                expected_sha256=final_hash,
                policy_event=policy_event,
                trusted_root=project["root_identity"],
                project=job.project,
                track=job.track,
                role=role,
                inspector=self.inspector,
            )
            if not result.ok or result.identity is None:
                raise ValidationError("; ".join(result.errors) or "verification failed")
            self.registry.bind_track_identity(
                job.project,
                job.track,
                result.identity.package_name,
                job.branch,
                provision_role=provision_role,
                provision_signer_profile=(
                    str(signer_profile) if provision_role is not None and signer_profile is not None else None
                ),
            )
            stable_packages = {
                rule.package_name for rule in policy.certificates if "production" in rule.roles
            }
            installable_alongside_stable = bool(stable_packages) and (
                result.identity.package_name not in stable_packages
            )
            maintainer_npub = encode_npub(str(project["root_identity"]))
            self.registry.assert_release_progress(
                job.project, job.track, result.identity.version_code, final_hash
            )
            expected_validator = project["validator_identity"]
            if expected_validator is not None and self.receipt_signer.pubkey != expected_validator:
                raise ValidationError("configured receipt signer does not match the project validator")
            confirmed_servers = self.blob_store.ensure(
                apk,
                final_hash,
                "application/vnd.android.package-archive",
                final_size,
            )
            release_servers = list(confirmed_servers) or self.blossom_servers
            published_at = unix_now()
            metadata = ReleaseMetadata(
                project=job.project,
                track=job.track,
                version_name=result.identity.version_name,
                version_code=result.identity.version_code,
                branch=job.branch,
                commit=job.commit,
                created_at=job.created_at,
                apk_sha256=final_hash,
                apk_size=final_size,
                package_name=result.identity.package_name,
                certificate_sha256=result.identity.certificate_sha256,
                maintainer_npub=maintainer_npub,
                installable_alongside_stable=installable_alongside_stable,
                policy_event_id=policy_event.id,
                policy_version=policy.version,
                published_at=published_at,
                blossom_servers=tuple(release_servers),
                submitter_pubkey=job.submitter_pubkey,
            )
            metadata_bytes = canonical_json(metadata.model_dump(mode="json"))
            metadata_hash = sha256_bytes(metadata_bytes)
            if ci_job is not None:
                with self.registry.connect() as db:
                    revoked = db.execute("SELECT revoked FROM ci_grants WHERE job_id=?", (job.id,)).fetchone()
                if (
                    revoked is None
                    or revoked["revoked"]
                    or self.ci_policy_file is None
                    or ci_grants.policy_digest(self.ci_policy_file) != evidence["policy_sha256"]
                ):
                    raise ValidationError("CI authorization revoked before publication")
            receipt = release_receipt(metadata, self.receipt_signer)
            if heartbeat_errors:
                raise heartbeat_errors[0]
            if not self.registry.renew_lease(job.id, worker_id, self.lease_seconds):
                raise ConflictError("job lease was lost during publication")
            self.registry.commit_release(
                job_id=job.id,
                apk_hash=final_hash,
                apk_size=final_size,
                metadata_hash=metadata_hash,
                version_name=result.identity.version_name,
                version_code=result.identity.version_code,
                package_name=result.identity.package_name,
                certificate_sha256=result.identity.certificate_sha256,
                maintainer_npub=maintainer_npub,
                installable_alongside_stable=installable_alongside_stable,
                policy_event_id=policy_event.id,
                published_at=published_at,
                receipt_event=receipt,
                blossom_servers=release_servers,
                lease_owner=worker_id,
                provision_role=provision_role,
                provision_signer_profile=(
                    str(signer_profile) if provision_role is not None and signer_profile is not None else None
                ),
            )
            self.flush_receipt_outbox()
        except Exception as exc:
            self.registry.fail_job(job.id, str(exc), lease_owner=worker_id)
        finally:
            heartbeat_stop.set()
            heartbeat.join(timeout=max(1.0, self.lease_heartbeat_seconds * 2))
        completed = self.registry.job(job.id)
        if completed.status in {JobStatus.PUBLISHED, JobStatus.FAILED}:
            self._remove_terminal_job_staging(completed, final_hash)
        return completed

    def _remove_terminal_job_staging(self, job: Job, final_hash: str) -> None:
        retained_hashes, _active_job_ids = self.registry.staging_references()
        paths = {
            self.staging_directory / f"signed-{job.id}.apk",
            self.staging_directory / f"signed-{job.id}.apk.idsig",
        }
        for digest in {job.candidate_sha256, final_hash} - retained_hashes:
            paths.add(self.staging_directory / f"{digest}.apk")
        for path in paths:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                # Publication state is authoritative. A later reconciliation
                # pass can remove a file that is temporarily busy or unwritable.
                continue

    def prune_staging(self, grace_seconds: int = 3600, now: float | None = None) -> list[str]:
        """Remove managed staging files not referenced by a queued or leased job."""
        retained_hashes, active_job_ids = self.registry.staging_references()
        cutoff = (time.time() if now is None else now) - grace_seconds
        deleted: list[str] = []
        for path in self.staging_directory.iterdir():
            try:
                should_skip = path.is_symlink() or not path.is_file() or path.stat().st_mtime > cutoff
            except FileNotFoundError:
                continue
            if should_skip:
                continue
            candidate = self._CANDIDATE_FILE.fullmatch(path.name)
            signed = self._SIGNED_FILE.fullmatch(path.name)
            if candidate is not None:
                if candidate.group("sha256") in retained_hashes:
                    continue
            elif signed is not None:
                if signed.group("job_id") in active_job_ids:
                    continue
            else:
                continue
            try:
                path.unlink()
            except FileNotFoundError:
                continue
            deleted.append(path.name)
        return sorted(deleted)

    def flush_receipt_outbox(self) -> None:
        with self._receipt_lock:
            # Backfill immutable, per-build coordinates for releases created
            # before build history was introduced. Signing is deterministic,
            # and the outbox insert is idempotent.
            for row in self.registry.release_history():
                raw = row.get("receipt_event_json")
                if not raw:
                    continue
                previous = NostrEvent.model_validate_json(raw)
                metadata = ReleaseMetadata.model_validate_json(previous.content)
                event = release_receipt(metadata, self.receipt_signer)
                self.registry.enqueue_receipt(event)
            for event in self.registry.pending_receipts():
                self.receipt_network.publish(event)
                self.registry.deliver_receipt(event.id)

    def flush_manifest_outbox(self) -> None:
        with self._manifest_lock:
            pending = self.registry.pending_outbox()
            if not pending:
                return
            paths = self.registry.paths()
            tags = manifest_tags(paths, self.blossom_servers)
            created_at = unix_now()
            manifest = self.signer.sign(created_at, ROOT_MANIFEST_KIND, tags, "")
            snapshot = self.signer.sign(created_at, SNAPSHOT_KIND, snapshot_tags(manifest), "")
            self.event_network.publish(manifest)
            self.event_network.publish(snapshot)
            self.registry.deliver_outbox_through(int(pending[-1]["id"]))

    def sync_site(
        self,
        directory: Path,
        *,
        upload_missing: bool = True,
        publish_manifest: bool = True,
    ) -> tuple[int, bool]:
        """Adopt the complete immutable app; release data remains outside its manifest."""
        root = directory.resolve(strict=True)
        if not root.is_dir():
            raise ValidationError("site source must be a directory")
        assets: list[tuple[str, str, int, str]] = []
        for source in sorted(root.rglob("*")):
            if source.is_symlink():
                raise ValidationError(f"site source contains a symlink: {source.relative_to(root)}")
            if not source.is_file():
                continue
            relative_path = source.relative_to(root)
            relative = relative_path.as_posix()
            if (
                not relative
                or relative.startswith(".")
                or any(part in {".", ".."} for part in relative_path.parts)
            ):
                raise ValidationError(f"unsafe site path: {relative}")
            digest, size = sha256_file(str(source))
            content_type = mimetypes.guess_type(source.name)[0] or "application/octet-stream"
            if not self.blob_store.exists(digest, size):
                if not upload_missing:
                    raise ValidationError(f"site blob is missing from Blossom: /{relative} ({digest})")
                self.blob_store.upload(source, digest, content_type)
                if not self.blob_store.exists(digest, size):
                    raise ValidationError(f"Blossom did not confirm site blob: /{relative}")
            assets.append((f"/{relative}", digest, size, content_type))
        if not assets:
            raise ValidationError("site source contains no files")
        changed = self.registry.replace_site_paths(assets)
        if publish_manifest:
            self.flush_manifest_outbox()
        return len(assets), changed

    def garbage_collect(self, grace_seconds: int, now: int | None = None) -> list[str]:
        deleted: list[str] = []
        for sha256, _size in self.registry.gc_candidates(grace_seconds, now):
            effective_now = now or unix_now()
            if self.registry.collect_blob(sha256, grace_seconds, effective_now, self.blob_store.delete):
                deleted.append(sha256)
        return deleted
