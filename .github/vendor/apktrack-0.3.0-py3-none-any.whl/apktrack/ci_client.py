"""Secretless CI client: exchange GitHub job identity for a bounded upload grant."""

import os
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import httpx

from .ci import AUDIENCE, CIRequest
from .errors import ValidationError


def exchange(server_url: str, operation: str, request: CIRequest) -> dict[str, Any]:
    if operation not in {"reservations", "grants"}:
        raise ValidationError("unsupported CI operation")
    endpoint = urlsplit(server_url)
    if (
        endpoint.scheme != "https"
        or endpoint.username
        or endpoint.password
        or endpoint.query
        or endpoint.fragment
    ):
        raise ValidationError("CI admission requires a clean HTTPS service URL")
    url = urlsplit(os.environ.get("ACTIONS_ID_TOKEN_REQUEST_URL", ""))
    request_token = os.environ.get("ACTIONS_ID_TOKEN_REQUEST_TOKEN")
    if (
        url.scheme != "https"
        or not url.hostname
        or url.username
        or url.password
        or not url.hostname.endswith(".actions.githubusercontent.com")
        or not request_token
    ):
        raise ValidationError("GitHub OIDC job identity is unavailable")
    query = [(k, v) for k, v in parse_qsl(url.query) if k != "audience"] + [("audience", AUDIENCE)]
    oidc_url = urlunsplit(url._replace(query=urlencode(query)))
    try:
        with httpx.Client(timeout=30, follow_redirects=False) as client:
            identity = client.get(oidc_url, headers={"Authorization": f"Bearer {request_token}"})
            identity.raise_for_status()
            token = identity.json()["value"]
            response = client.post(
                f"{server_url.rstrip('/')}/v2/ci/{operation}",
                json=request.model_dump(mode="json"),
                headers={"Authorization": f"Bearer {token}"},
            )
            response.raise_for_status()
            return dict(response.json())
    except (httpx.HTTPError, KeyError, ValueError) as exc:
        # Never propagate response bodies, URLs or headers containing job credentials.
        raise ValidationError("CI admission exchange failed") from exc
