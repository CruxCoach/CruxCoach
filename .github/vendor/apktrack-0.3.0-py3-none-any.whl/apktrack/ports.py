from pathlib import Path
from typing import Protocol

from .models import ApkIdentity, NostrEvent


class ApkInspector(Protocol):
    def inspect(self, apk: Path) -> ApkIdentity: ...


class BlobStore(Protocol):
    def ensure(self, path: Path, sha256: str, content_type: str, expected_size: int) -> tuple[str, ...]: ...

    def upload(self, path: Path, sha256: str, content_type: str) -> None: ...

    def exists(self, sha256: str, expected_size: int) -> bool: ...

    def delete(self, sha256: str) -> None: ...


class EventSigner(Protocol):
    @property
    def pubkey(self) -> str: ...

    def sign(self, created_at: int, kind: int, tags: list[list[str]], content: str) -> NostrEvent: ...


class EventNetwork(Protocol):
    def publish(self, event: NostrEvent) -> None: ...


class ApkSigner(Protocol):
    def sign(self, source: Path, destination: Path, profile: str) -> None: ...
