"""Private, Development-only receipt signer: validates a queued job, never arbitrary Nostr data.

Run the server under a separate OS user. Only this service may read its validator
credential. Its caller gets a Unix socket, not key files or a bunker connection.
"""

import json
import os
import shutil
import socket
import socketserver
import stat
import sys
import tempfile
from pathlib import Path
from typing import Any

from pydantic import Field

from . import ci_grants
from .adapters.nostr import FileNostrSigner
from .canonical import canonical_json, sha256_file
from .errors import ValidationError
from .models import ReleaseMetadata, StrictModel, unix_now
from .nostr import encode_npub, event_dict
from .receipt import receipt_payload, release_receipt
from .sandbox_inspector import SandboxedAndroidInspector
from .storage import ReadOnlyRegistry, Registry
from .verification import verify_release

MAX_REQUEST = 65536


class ReceiptRequest(StrictModel):
    created_at: int = Field(ge=0)
    kind: int
    tags: list[list[str]]
    content: str


class ReceiptGuard:
    def __init__(self, registry: Registry, staging: Path, policy: Path, signer: Any, inspector: Any) -> None:
        self.registry, self.staging, self.policy = registry, staging, policy
        self.signer, self.inspector = signer, inspector

    def sign(self, payload: str) -> dict[str, Any]:
        request = ReceiptRequest.model_validate_json(payload)
        metadata = ReleaseMetadata.model_validate_json(request.content)
        # Reconstruct every field/tag; disallow hidden extra tags and alternate event kinds.
        expected = receipt_payload(metadata)
        if request.model_dump() != expected or abs(unix_now() - metadata.published_at) > 300:
            raise ValidationError("not a canonical current release receipt")
        project = self.registry.project(metadata.project)
        if (
            project["validator_identity"] != self.signer.pubkey
            or metadata.maintainer_npub != encode_npub(project["root_identity"])
            or not self.registry.remote_upload_allowed(metadata.project, metadata.track)
        ):
            raise ValidationError("receipt scope is not authorized Development")
        with self.registry.connect() as db:
            rows = db.execute(
                "SELECT jobs.*,ci_grants.evidence,ci_grants.version_code,ci_grants.revoked "
                "FROM jobs JOIN ci_grants ON ci_grants.job_id=jobs.id "
                "WHERE jobs.project=? AND jobs.track=? AND jobs.commit_hash=? AND jobs.status='leased'",
                (metadata.project, metadata.track, metadata.commit),
            ).fetchall()
        if len(rows) != 1:
            raise ValidationError("receipt needs exactly one authorized leased CI job")
        job = rows[0]
        evidence = json.loads(job["evidence"])
        if (
            job["revoked"]
            or ci_grants.policy_digest(self.policy) != evidence["policy_sha256"]
            or metadata.branch != job["branch"]
            or metadata.created_at != job["created_at"]
            or metadata.submitter_pubkey != job["submitter_pubkey"]
            or metadata.version_code != job["version_code"]
            or metadata.package_name != evidence["package_name"]
        ):
            raise ValidationError("receipt does not match approved CI job")
        event, policy = self.registry.latest_policy(metadata.project)
        if metadata.policy_event_id != event.id or metadata.policy_version != policy.version:
            raise ValidationError("receipt must use the current Root policy")
        # Copy into a signer-owned snapshot. No symlinks; hash again after the copy.
        path = self.staging / f"{metadata.apk_sha256}.apk"
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
        with os.fdopen(descriptor, "rb") as source, tempfile.TemporaryDirectory() as directory:
            if not stat.S_ISREG(os.fstat(source.fileno()).st_mode):
                raise ValidationError("receipt APK must be a regular file")
            if os.fstat(source.fileno()).st_size != metadata.apk_size:
                raise ValidationError("receipt APK size mismatch")
            snapshot = Path(directory) / "candidate.apk"
            with snapshot.open("wb") as target:
                shutil.copyfileobj(source, target)
            digest, size = sha256_file(str(snapshot))
            if digest != metadata.apk_sha256 or size != metadata.apk_size:
                raise ValidationError("receipt APK bytes mismatch")
            result = verify_release(
                snapshot,
                digest,
                event,
                project["root_identity"],
                metadata.project,
                metadata.track,
                "development",
                self.inspector,
            )
            if not result.ok or result.identity is None:
                raise ValidationError("receipt APK verification failed")
            identity = result.identity
            if (
                identity.package_name != metadata.package_name
                or identity.certificate_sha256 != metadata.certificate_sha256
                or identity.version_code != metadata.version_code
                or identity.version_name != metadata.version_name
            ):
                raise ValidationError("receipt APK identity mismatch")
        stable_packages = {r.package_name for r in policy.certificates if "production" in r.roles}
        alongside = bool(stable_packages) and metadata.package_name not in stable_packages
        if alongside != metadata.installable_alongside_stable:
            raise ValidationError("incorrect production separation claim")
        if ci_grants.policy_digest(self.policy) != evidence["policy_sha256"]:
            raise ValidationError("authorization changed while checking APK")
        return event_dict(release_receipt(metadata, self.signer))


def serve(config: Path) -> None:
    options = json.loads(config.read_text())
    signer = FileNostrSigner(Path(options["validator_credential"]))
    registry = ReadOnlyRegistry(Path(options["database"]))
    project = registry.project(options["project"])
    if project["root_identity"] != options["root_identity"]:
        raise ValidationError("private signer Root pin mismatch")
    guard = ReceiptGuard(
        ReadOnlyRegistry(Path(options["database"])),
        Path(options["staging"]),
        Path(options["ci_policy"]),
        signer,
        SandboxedAndroidInspector(Path(options["build_tools"])),
    )

    class Handler(socketserver.StreamRequestHandler):
        def handle(self) -> None:
            self.connection.settimeout(300)
            result: dict[str, Any]
            try:
                raw = self.rfile.readline(MAX_REQUEST + 1)
                if len(raw) > MAX_REQUEST or not raw.endswith(b"\n"):
                    raise ValueError("invalid request frame")
                request = json.loads(raw)
                if request == {"action": "get-public-key"}:
                    result = {"result": signer.pubkey}
                elif set(request) == {"action", "payload"} and request["action"] == "sign-event":
                    envelope = ReceiptRequest.model_validate_json(request["payload"])
                    metadata = ReleaseMetadata.model_validate_json(envelope.content)
                    if metadata.project != options["project"] or not set(metadata.blossom_servers).issubset(
                        options["blossom_servers"]
                    ):
                        raise ValueError("receipt project or mirror is outside the signer policy")
                    if registry.project(metadata.project)["root_identity"] != options["root_identity"]:
                        raise ValueError("receipt Root changed")
                    result = {"result": guard.sign(request["payload"])}
                else:
                    raise ValueError("unsupported signer operation")
            except Exception:
                result = {"error": "receipt signing request rejected"}
            self.wfile.write(canonical_json(result) + b"\n")

    socket_path = Path(options["socket"])
    socket_path.parent.mkdir(parents=True, exist_ok=True)
    # Refuse an existing socket instead of unlinking another live service's endpoint.
    with socketserver.UnixStreamServer(str(socket_path), Handler) as server:
        os.chmod(socket_path, 0o660)
        try:
            server.serve_forever()
        finally:
            socket_path.unlink(missing_ok=True)


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--socket", type=Path)
    parser.add_argument("--serve", type=Path)
    parser.add_argument("action", nargs="?", choices=["get-public-key", "sign-event"])
    args = parser.parse_args()
    if args.serve:
        serve(args.serve)
        return
    if args.socket is None or args.action is None:
        parser.error("client requires --socket and an action")
    request = {"action": args.action}
    if args.action == "sign-event":
        request["payload"] = sys.stdin.read(MAX_REQUEST + 1)
    wire = canonical_json(request) + b"\n"
    if len(wire) > MAX_REQUEST:
        raise SystemExit("receipt request too large")
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as connection:
        connection.settimeout(300)
        connection.connect(str(args.socket))
        connection.sendall(wire)
        with connection.makefile("rb") as stream:
            result = json.loads(stream.readline(MAX_REQUEST + 1))
    if "error" in result:
        raise SystemExit("receipt signing request rejected")
    value = result["result"]
    print(value if isinstance(value, str) else json.dumps(value))
