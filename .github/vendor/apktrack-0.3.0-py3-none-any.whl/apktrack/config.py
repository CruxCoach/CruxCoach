from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="APKTRACK_", extra="ignore")

    database: Path = Path("data/apktrack.db")
    staging_directory: Path = Path("data/staging")
    local_blob_directory: Path = Path("data/blobs")
    backend: Literal["local", "network"] = "local"
    public_url: str | None = None
    blossom_url: str = "http://127.0.0.1:3001"
    blossom_urls: str | None = None
    event_server_url: str = "ws://127.0.0.1:7777"
    receipt_event_server_url: str | None = None
    receipt_event_server_urls: str | None = None
    operational_secret_env: str = "APKTRACK_OPERATIONAL_NSEC_HEX"
    event_signer_command: str | None = None
    receipt_secret_env: str = "APKTRACK_RECEIPT_NSEC_HEX"
    receipt_secret_file: Path | None = None
    receipt_signer_command: str | None = None
    max_apk_bytes: int = 250 * 1024 * 1024
    upload_rate_per_minute: int = Field(default=12, ge=1)
    max_concurrent_uploads: int = Field(default=4, ge=1)
    max_concurrent_uploads_per_token: int = Field(default=1, ge=1)
    admin_token_env: str = "APKTRACK_ADMIN_TOKEN"
    apk_signer_command: str | None = None
    apk_inspector_command: str | None = None
    ci_policy_file: Path | None = None
    ci_only_projects: tuple[str, ...] = ()

    @field_validator("public_url")
    @classmethod
    def public_url_is_https(cls, value: str | None) -> str | None:
        if value is not None and not value.startswith("https://"):
            raise ValueError("public_url must use HTTPS")
        return value
