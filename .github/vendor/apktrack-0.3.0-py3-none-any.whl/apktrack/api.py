import hashlib
import hmac
import os
import tempfile
import time
from collections import defaultdict, deque
from pathlib import Path
from typing import cast

from fastapi import Body, Depends, FastAPI, File, Form, Header, HTTPException, Query, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse
from pydantic import ValidationError as PydanticValidationError

from . import ci_grants
from .ci import CIRequest, GitHubAuthority
from .config import Settings
from .errors import APKTrackError, ConflictError, NotFoundError
from .http_auth import verify_nip98
from .models import HEX64, BuildRequest, Job, VersionReservation, unix_now
from .runtime import build_service
from .service import APKTrackService


def create_app(service: APKTrackService | None = None, settings: Settings | None = None) -> FastAPI:
    settings = settings or Settings()
    service = service or build_service(settings)
    app = FastAPI(title="APKTrack", version="0.1.0")
    app.state.service = service
    app.state.settings = settings
    app.state.upload_history = defaultdict(deque)
    app.state.active_uploads = defaultdict(int)
    app.state.active_upload_count = 0
    app.state.ci_authority = GitHubAuthority(settings.ci_policy_file) if settings.ci_policy_file else None

    def current_service() -> APKTrackService:
        return cast(APKTrackService, app.state.service)

    @app.exception_handler(APKTrackError)
    async def apktrack_error(_request: object, exc: APKTrackError) -> JSONResponse:
        status = 409 if isinstance(exc, ConflictError) else 404 if isinstance(exc, NotFoundError) else 422
        return JSONResponse(status_code=status, content={"detail": str(exc)})

    @app.get("/healthz")
    def health() -> dict[str, str]:
        return {"status": "ok"}

    @app.get("/v2/blobs/{sha256}")
    def published_blob(
        sha256: str,
        track_service: APKTrackService = Depends(current_service),
    ) -> FileResponse:
        if not HEX64.fullmatch(sha256) or track_service.registry.published_blob(sha256) is None:
            raise HTTPException(status_code=404)
        path = track_service.staging_directory / f"{sha256}.apk"
        if not path.is_file():
            raise HTTPException(status_code=404)
        return FileResponse(
            path,
            media_type="application/vnd.android.package-archive",
            headers={
                "Access-Control-Allow-Origin": "*",
                "Cache-Control": "public, max-age=31536000, immutable",
                "Cross-Origin-Resource-Policy": "cross-origin",
            },
        )

    @app.post("/v1/builds", response_model=Job, status_code=202)
    def submit_build(
        project: str = Form(),
        track: str = Form(),
        branch: str = Form(),
        commit: str = Form(),
        idempotency_key: str = Form(),
        apk: UploadFile = File(),
        authorization: str | None = Header(default=None),
        track_service: APKTrackService = Depends(current_service),
    ) -> Job:
        try:
            request = BuildRequest(
                project=project,
                track=track,
                branch=branch,
                commit=commit,
                idempotency_key=idempotency_key,
            )
        except PydanticValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()) from exc
        if project in settings.ci_only_projects:
            raise HTTPException(status_code=403, detail="project requires bound CI admission")
        token = (authorization or "").removeprefix("Bearer ")
        if not track_service.registry.authenticate(token, project, track):
            raise HTTPException(status_code=401, detail="invalid or out-of-scope API token")
        suffix = ".apk"
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as stream:
            temporary = Path(stream.name)
            total = 0
            while chunk := apk.file.read(1024 * 1024):
                total += len(chunk)
                if total > track_service.max_apk_bytes:
                    temporary.unlink(missing_ok=True)
                    raise HTTPException(status_code=413, detail="APK exceeds configured size limit")
                stream.write(chunk)
        try:
            return track_service.submit(request, temporary)
        finally:
            temporary.unlink(missing_ok=True)

    @app.post("/v2/builds/{project}/{track}", response_model=Job, status_code=202)
    async def submit_build_nip98(
        project: str,
        track: str,
        request: Request,
        branch: str,
        commit: str,
        idempotency_key: str,
        authorization: str | None = Header(default=None),
        x_apktrack_token: str | None = Header(default=None),
        track_service: APKTrackService = Depends(current_service),
    ) -> Job:
        try:
            build = BuildRequest(
                project=project,
                track=track,
                branch=branch,
                commit=commit,
                idempotency_key=idempotency_key,
            )
        except PydanticValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()) from exc
        if not track_service.registry.remote_upload_allowed(project, track):
            raise HTTPException(
                status_code=403,
                detail="remote intake is limited to authorized development tracks",
            )
        is_ci = (x_apktrack_token or "").startswith("ci_")
        if is_ci:
            with track_service.registry.connect() as db:
                grant = ci_grants.check(db, x_apktrack_token or "", build)
            import json

            if (
                settings.ci_policy_file is None
                or ci_grants.policy_digest(settings.ci_policy_file)
                != json.loads(grant["evidence"])["policy_sha256"]
            ):
                raise HTTPException(status_code=403, detail="CI authorization revoked")
        elif project in settings.ci_only_projects or not track_service.registry.authenticate(
            x_apktrack_token or "", project, track
        ):
            raise HTTPException(status_code=401, detail="invalid or out-of-scope upload token")
        admission_key = hashlib.sha256((x_apktrack_token or "").encode()).hexdigest()
        now = time.monotonic()
        history = app.state.upload_history[admission_key]
        while history and history[0] <= now - 60:
            history.popleft()
        if len(history) >= settings.upload_rate_per_minute:
            raise HTTPException(status_code=429, detail="upload rate limit exceeded")
        if app.state.active_upload_count >= settings.max_concurrent_uploads:
            raise HTTPException(status_code=429, detail="global upload concurrency limit exceeded")
        if app.state.active_uploads[admission_key] >= settings.max_concurrent_uploads_per_token:
            raise HTTPException(status_code=429, detail="upload-token concurrency limit exceeded")
        history.append(now)
        app.state.active_upload_count += 1
        app.state.active_uploads[admission_key] += 1
        temporary: Path | None = None
        try:
            digest = hashlib.sha256()
            with tempfile.NamedTemporaryFile(suffix=".apk", delete=False) as stream:
                temporary = Path(stream.name)
                total = 0
                async for chunk in request.stream():
                    total += len(chunk)
                    if total > track_service.max_apk_bytes:
                        raise HTTPException(status_code=413, detail="APK exceeds configured size limit")
                    digest.update(chunk)
                    stream.write(chunk)
            try:
                verification_url = str(request.url)
                if settings.public_url is not None:
                    verification_url = f"{settings.public_url.rstrip('/')}{request.url.path}"
                    if request.url.query:
                        verification_url = f"{verification_url}?{request.url.query}"
                submitter = verify_nip98(
                    authorization,
                    url=verification_url,
                    method=request.method,
                    payload_sha256=digest.hexdigest(),
                    now=unix_now(),
                )
            except APKTrackError as exc:
                raise HTTPException(status_code=401, detail=str(exc)) from exc
            return track_service.submit(
                build,
                temporary,
                submitter_pubkey=submitter,
                ci_grant=x_apktrack_token if is_ci else None,
            )
        finally:
            app.state.active_upload_count -= 1
            app.state.active_uploads[admission_key] -= 1
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    @app.post(
        "/v2/versions/{project}/{track}/reservations",
        response_model=VersionReservation,
        status_code=201,
    )
    def reserve_development_version(
        project: str,
        track: str,
        branch: str,
        commit: str,
        idempotency_key: str,
        minimum: int = Query(default=1, ge=1, le=2_100_000_000),
        x_apktrack_token: str | None = Header(default=None),
        track_service: APKTrackService = Depends(current_service),
    ) -> VersionReservation:
        try:
            build = BuildRequest(
                project=project,
                track=track,
                branch=branch,
                commit=commit,
                idempotency_key=idempotency_key,
            )
        except PydanticValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()) from exc
        if not track_service.registry.remote_upload_allowed(project, track):
            raise HTTPException(
                status_code=403,
                detail="version allocation is limited to authorized development tracks",
            )
        if project in settings.ci_only_projects or not track_service.registry.authenticate(
            x_apktrack_token or "", project, track
        ):
            raise HTTPException(status_code=401, detail="invalid or out-of-scope upload token")
        return track_service.registry.reserve_development_version(
            build.project,
            build.track,
            build.branch,
            build.commit,
            build.idempotency_key,
            minimum,
        )

    @app.post("/v2/ci/reservations", response_model=VersionReservation, status_code=201)
    def ci_reserve(
        payload: CIRequest,
        authorization: str = Header(),
        track_service: APKTrackService = Depends(current_service),
    ) -> VersionReservation:
        if app.state.ci_authority is None:
            raise HTTPException(status_code=503, detail="CI admission is not configured")
        app.state.ci_authority.authorize(authorization.removeprefix("Bearer "), payload)
        b = payload.build
        if not track_service.registry.remote_upload_allowed(b.project, b.track):
            raise HTTPException(status_code=403, detail="CI only admits development tracks")
        from .ci import read_policy

        assert settings.ci_policy_file is not None
        policy = read_policy(settings.ci_policy_file)
        return track_service.registry.reserve_development_version(
            b.project,
            b.track,
            b.branch,
            b.commit,
            b.idempotency_key,
            policy["minimum_version_code"],
        )

    @app.post("/v2/ci/grants")
    def ci_issue(
        payload: CIRequest,
        authorization: str = Header(),
        track_service: APKTrackService = Depends(current_service),
    ) -> JSONResponse:
        if app.state.ci_authority is None:
            raise HTTPException(status_code=503, detail="CI admission is not configured")
        if payload.apk_sha256 is None:
            raise HTTPException(status_code=422, detail="APK hash is required")
        evidence = app.state.ci_authority.authorize(authorization.removeprefix("Bearer "), payload)
        token = ci_grants.issue(track_service.registry, payload.build, payload.apk_sha256, evidence)
        return JSONResponse(
            {"upload_token": token, "expires_in": 300},
            headers={"Cache-Control": "no-store", "Pragma": "no-cache"},
        )

    @app.get(
        "/v2/versions/{project}/{track}/reservations/{commit}",
        response_model=VersionReservation,
    )
    def get_version_reservation(
        project: str,
        track: str,
        commit: str,
        track_service: APKTrackService = Depends(current_service),
    ) -> VersionReservation:
        try:
            lookup = BuildRequest(
                project=project,
                track=track,
                branch="lookup",
                commit=commit,
                idempotency_key="lookup-only",
            )
        except PydanticValidationError as exc:
            raise HTTPException(status_code=422, detail=exc.errors()) from exc
        return track_service.registry.version_reservation(lookup.project, lookup.track, lookup.commit)

    @app.get("/v2/builds/{job_id}", response_model=Job)
    def get_public_job(
        job_id: str,
        track_service: APKTrackService = Depends(current_service),
    ) -> Job:
        return track_service.registry.job(job_id)

    @app.get("/v1/builds/{job_id}", response_model=Job)
    def get_job(
        job_id: str,
        authorization: str | None = Header(default=None),
        track_service: APKTrackService = Depends(current_service),
    ) -> Job:
        job = track_service.registry.job(job_id)
        token = (authorization or "").removeprefix("Bearer ")
        if not track_service.registry.authenticate(token, job.project, job.track):
            raise HTTPException(status_code=401, detail="invalid or out-of-scope API token")
        return job

    @app.post("/v1/policies/{project}")
    def import_policy(
        project: str,
        event: str = Body(),
        x_admin_token: str | None = Header(default=None),
        track_service: APKTrackService = Depends(current_service),
    ) -> dict[str, str]:
        expected = os.environ.get(settings.admin_token_env)
        if expected is None or x_admin_token is None or not hmac.compare_digest(expected, x_admin_token):
            raise HTTPException(status_code=401, detail="admin authorization unavailable or invalid")
        return {"event_id": track_service.import_policy(project, event)}

    @app.get("/v1/releases")
    def releases(track_service: APKTrackService = Depends(current_service)) -> list[dict[str, object]]:
        return track_service.registry.dashboard()

    @app.get("/blobs/{sha256}")
    def local_blob(sha256: str) -> FileResponse:
        if settings.backend != "local" or len(sha256) != 64:
            raise HTTPException(status_code=404)
        path = settings.local_blob_directory / sha256
        if not path.is_file():
            raise HTTPException(status_code=404)
        return FileResponse(path)

    @app.get("/{sha256}", include_in_schema=False)
    def local_bud01_blob(sha256: str) -> FileResponse:
        return local_blob(sha256)

    @app.get("/", response_class=HTMLResponse)
    def dashboard(track_service: APKTrackService = Depends(current_service)) -> str:
        rows = track_service.registry.dashboard()
        body = "".join(
            "<tr>"
            f"<td>{_html(row['project'])}</td><td>{_html(row['track'])}</td>"
            f"<td>{_html(row['version_name'])} ({_html(row['version_code'])})</td>"
            f"<td>{_html(row['branch'])}<br><code>{_html(row['commit_hash'])}</code></td>"
            f"<td>{_html(row['created_at'])}</td>"
            f"<td><code>{_html(row['apk_sha256'])}</code></td>"
            f"<td>{_html(row['package_name'])}</td>"
            f"<td><code>{_html(row['certificate_sha256'])}</code></td>"
            f"<td>{_html(row['maintainer_npub'])}</td>"
            f"<td>{'yes' if row['installable_alongside_stable'] else 'no'}</td>"
            "<td>apktrack-verified (see JSON + independent CLI)</td></tr>"
            for row in rows
        )
        return (
            "<!doctype html><html><head><meta charset=utf-8><title>APKTrack releases</title>"
            "<style>body{font:16px system-ui;max-width:1200px;margin:3rem auto;padding:0 1rem}"
            "table{border-collapse:collapse;width:100%}td,th{padding:.6rem;border-bottom:1px solid #ddd;"
            "text-align:left}code{font-size:.78em;word-break:break-all}.notice{background:#fff5cc;padding:1rem}"
            "</style></head><body><h1>APKTrack releases</h1>"
            "<p class=notice>This dashboard reports the APKTrack result. It is not a cryptographic "
            "verifier. Before first install, run <code>apktrack verify</code> against the APK and "
            "the latest Root policy.</p><table><thead><tr><th>Project</th><th>Channel</th>"
            "<th>Version</th><th>Branch / commit</th><th>Created</th><th>SHA-256</th>"
            "<th>Package</th><th>Signing certificate</th><th>Maintainer npub</th>"
            "<th>Alongside stable</th><th>Status</th></tr></thead>"
            f"<tbody>{body}</tbody></table></body></html>"
        )

    return app


def _html(value: object) -> str:
    import html

    return html.escape(str(value), quote=True)


app = create_app()
